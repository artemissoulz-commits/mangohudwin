# MangoHud Windows: experimental source port

This branch is **not safe to distribute as a finished application** and is **not functionally validated**.

## Changes
- DirectX12 headers use platform include paths instead of hardcoded Linux MinGW paths.
- Linux-only legacy GPU wrapper and its fdinfo/AMDGPU backends are not linked on Windows. This intentionally means **AMD/Intel telemetry is incomplete**, not secretly implemented. NVIDIA path is left intact but has not been verified.
- Windows config-file monitoring uses a portable filesystem polling implementation instead of Linux inotify.
- Meson uses optional libdrm on Windows.
- Windows-only CI workflow builds sources in MSYS2, never produces a public release.

## Must fix before release
- Implement Windows AMD/Intel GPU metrics using supported APIs and test on physical hardware.
- Audit and test DirectX11/12 and Vulkan injection paths, especially thread lifecycle and anti-cheat restrictions.
- Verify actual runtime operation, dependencies, installer and clean uninstall.
- Check binary architecture and signing; no unverified DLL should be inserted into a game.
