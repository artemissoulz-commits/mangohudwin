#include "client.h"
#include "ipc.h"
#include "server.h"
#include "ipc_abi_hash.h"

#include <cstdlib>
#include <filesystem>
#include <sys/stat.h>
#include <utility>

class IPCServer;

static std::string resolve_wayland_display(pid_t pid, const char* display)
{
    if (!display || display[0] != '/')
        return display ? display : "";

    const auto client_path = "/proc/" + std::to_string(pid) + "/root" + display;
    struct stat client_socket{};
    if (stat(client_path.c_str(), &client_socket) != 0 || !S_ISSOCK(client_socket.st_mode))
        return display;

    auto matches = [&](const std::filesystem::path& path) {
        struct stat socket{};
        return stat(path.c_str(), &socket) == 0 &&
               socket.st_dev == client_socket.st_dev && socket.st_ino == client_socket.st_ino;
    };
    if (matches(display))
        return display;

    if (const auto* runtime = std::getenv("XDG_RUNTIME_DIR")) {
        std::error_code error;
        const std::filesystem::directory_iterator end;
        for (std::filesystem::directory_iterator it(runtime, error); !error && it != end; it.increment(error))
            if (matches(it->path()))
                return it->path().string();
    }
    return client_path;
}

static OutputMode configured_output_mode(MangoHudServer* server)
{
    if (!server || !server->config)
        return OutputMode::Layer;

    const auto& output = server->config->get<std::string>("output");
    if (output == "app")
        return OutputMode::App;
    if (output == "layer")
        return OutputMode::Layer;
    if (output == "inject")
        return OutputMode::Inject;

    SPDLOG_ERROR("invalid output mode '{}', expected 'app', 'layer' or 'inject'", output);
    return OutputMode::Layer;
}

Client::Client(pid_t pid_, IPCServer* ipc_, MangoHudServer* server_, sd_bus* bus_)
    : pid(pid_),
      ipc(ipc_),
      server(server_),
      bus(bus_) {}

void Client::setup_handshake(std::string member, sd_bus_slot** slot,
                             sd_bus_message_handler_t callback, std::shared_ptr<Client>& shared) {
    std::string match =
        "type='signal',"
        "path='" + std::string(kObjPath) + "',"
        "interface='" + std::string(kIface) + "',"
        "member='" + member + "'";

    auto* weak = new std::weak_ptr<Client>(shared);
    int r = sd_bus_add_match(bus, slot, match.c_str(), callback, weak);
    if (r < 0) {
        SPDLOG_ERROR("match {} {} ({}) ObjPath: {} Iface: {}", member, r, strerror(-r), kObjPath, kIface);
        delete weak;
        *slot = nullptr;
        return;
    } else {
        sd_bus_slot_set_destroy_callback(*slot, [](void* p) {
            delete static_cast<std::weak_ptr<Client>*>(p);
        });
    }
}

void Client::init(std::shared_ptr<Client>& shared) {
    if (!shared) {
        set_dead();
        return;
    }

    self_weak = shared;

    setup_handshake("on_connect", &handshake_slot, &Client::on_connect, shared);
    setup_handshake("frame_samples", &frame_samples_slot, &Client::frame_samples, shared);
    setup_handshake("resolution", &resolution_slot, &Client::resolution, shared);
    setup_handshake("spdlog", &spdlog_slot, &Client::spdlog_msg, shared);
    setup_handshake("frame_ready", &frame_slot, &Client::on_frame, shared);
    setup_handshake("import_failed", &import_failed_slot,
                    &Client::on_import_failed, shared);

    stop_eventfd = eventfd(0, EFD_CLOEXEC);
    if (stop_eventfd < 0) { set_dead(); return; }

    work_eventfd = eventfd(0, EFD_NONBLOCK | EFD_CLOEXEC);
    if (work_eventfd < 0) { set_dead(); return; }

    event = nullptr;
    int r = sd_event_new(&event);
    if (r < 0) {
        SPDLOG_ERROR("sd_event_new {} ({})", r, strerror(-r));
        set_dead();
        return;
    }

    r = sd_bus_attach_event(bus, event, 0);
    if (r < 0) {
        SPDLOG_ERROR("sd_bus_attach_event {} ({})", r, strerror(-r));
        sd_event_unref(event);
        event = nullptr;
        set_dead();
        return;
    }

    if (work_eventfd < 0) {
        SPDLOG_ERROR("eventfd(work) failed ({})", strerror(errno));
        set_dead();
        return;
    }

    stop_src = nullptr;
    auto* stop_weak = new std::weak_ptr<Client>(shared);
    r = sd_event_add_io(event, &stop_src, stop_eventfd, EPOLLIN, &Client::on_stop_event, stop_weak);
    if (r < 0) {
        SPDLOG_ERROR("sd_event_add_io(stop_eventfd) {} ({})", r, strerror(-r));
        sd_event_unref(event);
        delete stop_weak;
        event = nullptr;
        set_dead();
        return;
    } else {
        sd_event_source_set_destroy_callback(stop_src, [](void* p) {
            delete static_cast<std::weak_ptr<Client>*>(p);
        });
    }

    work_src = nullptr;
    auto* work_weak = new std::weak_ptr<Client>(shared);
    r = sd_event_add_io(event, &work_src, work_eventfd, EPOLLIN, &Client::on_work_event, work_weak);
    if (r < 0) {
        sd_event_unref(event);
        event = nullptr;
        delete work_weak;
        SPDLOG_ERROR("sd_event_add_io(work_eventfd) {} ({})", r, strerror(-r));
        set_dead();
        return;
    } else {
        sd_event_source_set_destroy_callback(work_src, [](void* p) {
            delete static_cast<std::weak_ptr<Client>*>(p);
        });
    }

    thread = std::thread([this] { dbus_thread(); });
}

int Client::on_stop_event(sd_event_source *s, int fd, uint32_t revents, void *userdata) {
    (void)revents;
    (void)userdata;

    uint64_t v = 0;
    for (;;) {
        ssize_t n = read(fd, &v, sizeof(v));
        if (n > 0) {
            break;
        }
        if (n == -1 && errno == EINTR) {
            continue;
        }
        break;
    }

    sd_event *e = sd_event_source_get_event(s);
    sd_event_exit(e, 0);
    return 0;
}

int Client::on_bus_disconnected(sd_bus_message *m, void *userdata, sd_bus_error *ret_error) {
    (void)m;
    (void)ret_error;

    auto *self = static_cast<Client *>(userdata);
    SPDLOG_DEBUG("Client disconnected: {}", self->pid);
    self->set_dead();
    self->stop.store(true);
    return 0;
}

void Client::dbus_thread() {
    pthread_setname_np(pthread_self(), ("c_dbus " + std::to_string(pid)).substr(0, 15).c_str());

    int r = sd_event_loop(event);
    if (r < 0 && !stop.load())
        SPDLOG_ERROR("sd_event_loop {} ({})", r, strerror(-r));

    SPDLOG_DEBUG("dbus thread exited");
}

int Client::on_connect(sd_bus_message* m, void* userdata, sd_bus_error* ret_error) {
    auto* w = static_cast<std::weak_ptr<Client>*>(userdata);
    auto self = w->lock();
    if (!self)
        return 0;

    uint64_t peer_hash = 0;

    int r = sd_bus_message_read(m, "t", &peer_hash);
    if (r < 0) {
        SPDLOG_ERROR(
            "on_connect: expected IPC ABI hash first, got malformed/old message: {} ({}). Restart game/client and server.",
            r,
            strerror(-r)
        );
        self->set_dead();
        return 0;
    }

    if (peer_hash != MANGOHUD_IPC_ABI_HASH) {
        uint64_t local_hash = MANGOHUD_IPC_ABI_HASH;
        SPDLOG_ERROR(
            "IPC ABI mismatch: peer=0x{:016x}, local=0x{:016x}. Restart game/client and server.",
            peer_hash,
            local_hash
        );

        int sr = sd_bus_emit_signal(
            self->bus,
            kObjPath,
            kIface,
            "incompatible",
            ""
        );
        if (sr < 0)
            SPDLOG_DEBUG("failed to emit incompatible signal {} ({})", sr, strerror(-sr));
        else
            sd_bus_flush(self->bus);

        self->set_dead();
        return 0;
    }

    const char* engine = "";
    const char* vulkan_driver = "";
    const char* gpu_name = "";
    const char* wayland_display = "";
    int64_t render_minor = -1;
    int buffer_size = 0;
    int32_t raw_api = 0;
    int gamescope_session = 0;
    int wayland_surface = 0;
    r = sd_bus_message_read(m, "sxiisssbb", &engine, &render_minor, &buffer_size, &raw_api,
                            &vulkan_driver, &gpu_name, &wayland_display, &gamescope_session, &wayland_surface);
    if (r < 0) {
        SPDLOG_ERROR("on_connect read(sxiisssbb) {} ({})", r, strerror(-r));
        self->set_dead();
        return false;
    }
    self->pEngineName = engine;
    self->vulkanDriver = vulkan_driver;
    self->gpuName = gpu_name;
    self->wayland_display = resolve_wayland_display(self->pid, wayland_display);
    const auto client_wayland_display = self->wayland_display;
    if (gamescope_session) {
        self->output_mode = OutputMode::Layer;
    } else {
        const char* server_display = std::getenv("WAYLAND_DISPLAY");
        self->wayland_display = server_display ? server_display : "";
        self->output_mode = configured_output_mode(self->server);
        if (self->output_mode == OutputMode::App && !wayland_surface) {
            SPDLOG_DEBUG("client {} has no native Wayland surface, trying layer output", self->pid);
            self->output_mode = OutputMode::Layer;
        }
    }
    if (self->output_mode == OutputMode::Layer && !self->ensure_wayland()) {
        if (gamescope_session) {
            SPDLOG_ERROR("No usable Wayland output for client {}", self->pid);
            self->set_dead();
            return 0;
        }
        self->output_mode = wayland_surface ? OutputMode::App : OutputMode::Inject;
        SPDLOG_DEBUG("server Wayland output unavailable, falling back to {} output",
                     wayland_surface ? "app" : "inject");
    }
    if (self->output_mode == OutputMode::App)
        self->wayland_display = client_wayland_display;

    SPDLOG_DEBUG("client {} output mode={} wayland_display={} gamescope_session={}",
                 self->pid,
                 self->output_mode == OutputMode::Layer ? "layer" :
                 self->output_mode == OutputMode::Inject ? "inject" : "app",
                 self->wayland_display, gamescope_session != 0);

    if (self->server && self->server->metrics)
        self->server->metrics->add_client_pid(self->pid);
    if (self->output_mode == OutputMode::Layer)
        render_minor = self->wayland->render_minor;
    else if (self->output_mode == OutputMode::App && wayland_surface) {
        auto renderer = Wayland::render_device(self->wayland_display);
        if (renderer < 0) {
            SPDLOG_DEBUG("wayland: device feedback unavailable display={}, using application renderer",
                         self->wayland_display);
        } else {
            render_minor = renderer;
            SPDLOG_DEBUG("wayland: feedback render minor={} display={}", renderer, self->wayland_display);
        }
    }
    self->renderer = std::make_unique<Renderer>(self->server, self.get(), render_minor, buffer_size);

    self->send_config();

    return 0;
}

int Client::resolution(sd_bus_message* m, void* userdata, sd_bus_error*) {
    auto* w = static_cast<std::weak_ptr<Client>*>(userdata);
    auto self = w->lock();
    if (!self)
        return 0;

    uint32_t width = 0;
    uint32_t height = 0;
    int r = sd_bus_message_read(m, "uu", &width, &height);
    if (r < 0) {
        SPDLOG_ERROR("resolution: read {} ({})", r, strerror(-r));
        return 0;
    }

    {
        std::lock_guard lock(self->m);
        self->resolutionWidth = width;
        self->resolutionHeight = height;
    }

    return sd_bus_reply_method_return(m, "");
}

void Client::send_dmabuf(const std::vector<BufferSet>& buffers, uint32_t width, uint32_t height,
                         ExportMethod method)
{
    if (output_mode == OutputMode::Layer) {
        send_dmabuf_wayland(buffers, width, height, method);
        return;
    }

    send_dmabuf_ipc(buffers, width, height, method);
}

void Client::send_dmabuf_wayland(const std::vector<BufferSet>& buffers, uint32_t width, uint32_t height,
                                 ExportMethod method)
{
    auto target = ensure_wayland();
    if (!target) {
        SPDLOG_DEBUG("wayland output unavailable display={}", wayland_display);
        return;
    }

    auto self = self_weak.lock();
    if (!self)
        return;

    target->import_dmabuf(std::move(self), buffers, width, height, method);
}

void Client::send_dmabuf_ipc(const std::vector<BufferSet>& buffers, uint32_t width, uint32_t height,
                             ExportMethod method)
{
    if (buffers.empty()) {
        SPDLOG_ERROR("renderer: failed to export buffers, no buffers available");
        return;
    }

    std::vector<std::pair<unique_fd, unique_fd>> fds;
    fds.reserve(buffers.size());

    const bool use_opaque = method == OPAQUE_VULKAN;
    for (const auto& buf : buffers) {
        unique_fd dmabuf = unique_fd::dup(buf.dmabuf.gbm.fd);
        // Keep sending this for GL release_fence(), even when the visible image
        // is imported from an opaque Vulkan fd. TODO: add a separate non-image
        // GL fence path.
        unique_fd opaque = use_opaque
            ? unique_fd::dup(buf.opaque.fd)
            : unique_fd::dup(buf.dmabuf.gbm.fd);

        if (!dmabuf || !opaque) {
            SPDLOG_ERROR("renderer: failed to dup buffer fd");
            return;
        }

        fds.emplace_back(std::move(dmabuf), std::move(opaque));
    }

    const auto& last = buffers.back();
    const auto modifier = last.dmabuf.gbm.modifier;
    const auto offset = last.dmabuf.gbm.offset;
    const auto stride = last.dmabuf.gbm.stride;
    const auto fourcc = last.dmabuf.gbm.fourcc;
    const auto plane_size = last.dmabuf.gbm.plane_size;
    const auto opaque_size = last.opaque.size;
    const auto opaque_offset = last.opaque.offset;
    const Resolution resolution{width, height};

    auto self = self_weak.lock();
    if (!self)
        return;

    post([self, modifier, offset, stride, fourcc, plane_size, opaque_size,
          opaque_offset, resolution, fds = std::move(fds)]() {
        SPDLOG_DEBUG("sending dmabuf");
        sd_bus_message* msg = nullptr;
        int ret = sd_bus_message_new_signal(self->bus, &msg, kObjPath, kIface, "dmabuf");

        if (ret < 0) {
            SPDLOG_DEBUG("failed to set signal {}", ret);
            return ret;
        }

        ret = sd_bus_message_append(
            msg,
            "tuuutttuu",
            modifier,
            offset,
            stride,
            fourcc,
            plane_size,
            opaque_size,
            opaque_offset,
            resolution.w,
            resolution.h
        );

        if (ret < 0) {
            SPDLOG_DEBUG("failed to append to message {} ({})", ret, strerror(-ret));
            sd_bus_message_unref(msg);
            return ret;
        }

        ret = sd_bus_message_open_container(msg, 'a', "(hh)");
        if (ret < 0) {
            SPDLOG_DEBUG("sd_bus_message_open_container array {} ({})", ret, strerror(-ret));
            sd_bus_message_unref(msg);
            return ret;
        }

        for (const auto& fd_pair : fds) {
            ret = sd_bus_message_open_container(msg, 'r', "hh");
            if (ret < 0) {
                SPDLOG_DEBUG("sd_bus_message_open_container struct {} ({})", ret, strerror(-ret));
                break;
            }

            ret = sd_bus_message_append(
                msg,
                "hh",
                fd_pair.first.get(),
                fd_pair.second.get()
            );

            if (ret < 0) {
                SPDLOG_DEBUG("sd_bus_message_append fds {} ({})", ret, strerror(-ret));
                int cr = sd_bus_message_close_container(msg);
                if (cr < 0) {
                    SPDLOG_DEBUG("sd_bus_message_close_container struct {} ({})", cr, strerror(-cr));
                }
                break;
            }

            ret = sd_bus_message_close_container(msg);
            if (ret < 0) {
                SPDLOG_DEBUG("sd_bus_message_close_container struct {} ({})", ret, strerror(-ret));
                break;
            }
        }

        ret = sd_bus_message_close_container(msg);
        if (ret < 0) {
            sd_bus_message_unref(msg);
            return ret;
        }

        ret = sd_bus_send(self->bus, msg, nullptr);
        sd_bus_message_unref(msg);
        if (ret < 0) {
            self->set_dead();
            SPDLOG_DEBUG("sd_bus_send {} ({})", ret, strerror(-ret));
            return ret;
        }

        return 0;
    });
}

void Client::send_config() {
    const double fps_limit = server->config->get<double>("fps_limit");
    auto self = self_weak.lock();
    if (!self)
        return;

    post([self, fps_limit]() {
        sd_bus_message* msg = nullptr;

        int r = sd_bus_message_new_signal(self->bus, &msg, kObjPath, kIface, "config");

        if (r < 0) {
            SPDLOG_DEBUG("failed to set signal {}", r);
            return r;
        }

        r = sd_bus_message_append(msg, "dbb", fps_limit,
                                  static_cast<int>(self->output_mode == OutputMode::Layer),
                                  static_cast<int>(self->output_mode == OutputMode::Inject));
        SPDLOG_DEBUG("sent fps_limit: {}", fps_limit);

        if (r < 0) {
            SPDLOG_DEBUG("failed to append to message {}", r);
            sd_bus_message_unref(msg);
            return r;
        }

        r = sd_bus_send(self->bus, msg, nullptr);
        sd_bus_message_unref(msg);
        if (r < 0) {
            self->set_dead();
            SPDLOG_DEBUG("failed to send message {}", r);
            return r;
        }
        sd_bus_flush(self->bus);
        return 0;
    });
}

int Client::frame_samples(sd_bus_message* m, void* userdata, sd_bus_error* ret_error) {
    auto* w = static_cast<std::weak_ptr<Client>*>(userdata);
    auto self = w->lock();
    if (!self)
        return 0;

    int x11_focused = 0;
    int r = sd_bus_message_read(m, "b", &x11_focused);
    if (r <= 0) {
        SPDLOG_ERROR("frame_samples: missing X11 focus ({})", r);
        return r < 0 ? r : -EINVAL;
    }
    std::vector<std::string> focused_seats;
    r = sd_bus_message_enter_container(m, 'a', "s");
    if (r < 0) {
        SPDLOG_ERROR("frame_samples: enter focused seats {} ({})", r, strerror(-r));
        return r;
    }

    for (;;) {
        const char* seat = nullptr;
        r = sd_bus_message_read(m, "s", &seat);
        if (r < 0) {
            SPDLOG_ERROR("frame_samples: read focused seat {} ({})", r, strerror(-r));
            return r;
        }
        if (r == 0)
            break;
        if (seat)
            focused_seats.emplace_back(seat);
    }

    r = sd_bus_message_exit_container(m);
    if (r < 0) {
        SPDLOG_ERROR("frame_samples: exit focused seats {} ({})", r, strerror(-r));
        return r;
    }

    r = sd_bus_message_enter_container(m, 'a', "(ytt)");
    if (r < 0) {
        SPDLOG_ERROR("frame_samples: enter samples {} ({})", r, strerror(-r));
        return r;
    }

    std::lock_guard client_lock(self->m);
    self->focused_seats = std::move(focused_seats);
    self->x11_focused = x11_focused;
    for (;;) {
        uint8_t type_raw = 0;
        uint64_t seq = 0, t_ns = 0;
        r = sd_bus_message_read(m, "(ytt)", &type_raw, &seq, &t_ns);
        if (r < 0) return r;
        if (r == 0) break;
        if (type_raw >= static_cast<uint8_t>(SampleType::Count)) {
            SPDLOG_ERROR("Invalid sample type {}", type_raw);
            return sd_bus_error_setf(ret_error, SD_BUS_ERROR_INVALID_ARGS,
                                     "Invalid sample type %u", type_raw);
        }

        auto type = static_cast<SampleType>(type_raw);
        auto& stats = self->stats_for(type);
        stats.add_sample(type, seq, t_ns);
    }

    r = sd_bus_message_exit_container(m);
    return sd_bus_reply_method_return(m, "");
}

void Client::set_dead() {
    active.store(false);
}

int Client::on_work_event(sd_event_source *s, int fd, uint32_t revents, void *userdata) {
    auto* w = static_cast<std::weak_ptr<Client>*>(userdata);
    auto self = w->lock();
    if (!self)
        return 0;
    if (!self->active.load())
        return 0;

    uint64_t v = 0;
    while (read(fd, &v, sizeof(v)) == sizeof(v)) {}

    for (;;) {
        std::packaged_task<void()> task;
        {
            std::lock_guard<std::mutex> lock(self->work_mtx);
            if (self->work_q.empty())
                return 0;

            task = std::move(self->work_q.front());
            self->work_q.pop();
        }
        task();
    }

    return 0;
}

Client::~Client() {
    sd_bus_slot_unref(handshake_slot);
    sd_bus_slot_unref(frame_samples_slot);
    sd_bus_slot_unref(resolution_slot);
    sd_bus_slot_unref(spdlog_slot);
    sd_bus_slot_unref(frame_slot);
    sd_bus_slot_unref(import_failed_slot);

    sd_event_source_disable_unref(stop_src);
    stop_src = nullptr;

    sd_event_source_disable_unref(work_src);
    work_src = nullptr;

    sd_bus_detach_event(bus);

    sd_event_unref(event);
    event = nullptr;

    if (bus) {
        sd_bus_unref(bus);
        bus = nullptr;
    }

    if (work_eventfd >= 0) {
        close(work_eventfd);
        work_eventfd = -1;
    }

    if (stop_eventfd >= 0) {
        close(stop_eventfd);
        stop_eventfd = -1;
    }
}

void Client::stop_and_join() {
    {
        std::lock_guard lock(m);
        stop.store(true, std::memory_order_release);
    }
    uint64_t one = 1;
    for (;;) {
        ssize_t n = write(stop_eventfd, &one, sizeof(one));
        if (n == (ssize_t)sizeof(one)) {
            break;
        }
        if (n < 0 && errno == EINTR) {
            continue;
        }
        break;
    }

    if (thread.joinable()) {
        thread.join();
    }

    std::unique_ptr<Renderer> stopped_renderer;
    {
        std::lock_guard lock(m);
        stopped_renderer = std::move(renderer);
    }
    stopped_renderer.reset();
    wayland.reset();

    std::queue<std::packaged_task<void()>> drain;
    {
        std::lock_guard<std::mutex> lock(work_mtx);
        work_q.swap(drain);
    }
}

int Client::spdlog_msg(sd_bus_message* m, void* userdata, sd_bus_error*) {
    auto* w = static_cast<std::weak_ptr<Client>*>(userdata);
    auto self = w->lock();
    if (!self)
        return 0;

    int level;
    const char* f = "";
    int line;
    const char* t = "";
    int r = sd_bus_message_read(m, "isis", &level, &f, &line, &t);
    std::string file = f;
    std::string text = t;

    if (r < 0)
        return r;

    if (!self->logger) {
        auto sink = std::make_shared<spdlog::sinks::stderr_color_sink_mt>();
        //TODO this should probably be a unique name in the future
        auto name = std::string("\x1b[38;2;173;100;193m") + "MANGOHUD" + "\x1b[0m" +
                    " " +
                    "\x1b[38;2;46;151;98m" + std::string("CLIENT") + "\x1b[0m";
        self->logger = std::make_shared<spdlog::logger>(name, sink);
        self->logger->set_level(spdlog::get_level());
        self->logger->set_pattern("[%Y-%m-%d %H:%M:%S.%e] [%n] [%^%l%$] [%s:%#] %v");
    }

    spdlog::source_loc loc{file.c_str(), line, ""};
    auto lvl = static_cast<spdlog::level::level_enum>(level);
    self->logger->log(loc, lvl, "{}", text);
    return 0;
}

void Client::frame_ready(int idx, unique_fd fd, std::shared_ptr<Renderer::Resources> resources) {
    if (idx < 0)
        return;

    auto self = self_weak.lock();
    if (!self)
        return;

    if (output_mode == OutputMode::Layer) {
        auto target = ensure_wayland();
        if (!target) {
            SPDLOG_DEBUG("wayland output unavailable display={}", wayland_display);
            return;
        }

        target->frame_ready(std::move(self), idx, std::move(fd), std::move(resources));
        stats_for(SampleType::Hud).add_sample(SampleType::Hud,
                                            hud_seq.fetch_add(1, std::memory_order_relaxed),
                                            os_time_get_nano());
        return;
    }

    post([self, idx, fd = std::move(fd)]() {
        int r = sd_bus_emit_signal(self->bus, kObjPath, kIface, "frame_ready", "uh",
                                   static_cast<uint32_t>(idx), fd.get());
        if (r < 0) {
            SPDLOG_ERROR("sd_bus_emit_signal {} ({})", r, strerror(-r));
            return r;
        }

        self->stats_for(SampleType::Hud).add_sample(SampleType::Hud,
                                                    self->hud_seq.fetch_add(1, std::memory_order_relaxed),
                                                    os_time_get_nano());
        return 0;
    });
}

std::shared_ptr<Wayland> Client::ensure_wayland()
{
    if (wayland && wayland->connected())
        return wayland;

    if (!server || wayland_display.empty())
        return nullptr;

    wayland = server->wayland(wayland_display);
    return wayland;
}

int Client::on_frame(sd_bus_message* m, void* userdata, sd_bus_error*) {
    auto* w = static_cast<std::weak_ptr<Client>*>(userdata);
    auto self = w->lock();
    if (!self)
        return 0;

    uint32_t idx = 0;
    int fd;
    int r = sd_bus_message_read(m, "uh", &idx, &fd);
    if (r < 0) {
        SPDLOG_ERROR("sd_bus_call_method {} ({})", r, strerror(-r));
        return r;
    }

    if (self->renderer)
        self->renderer->frame_ready(static_cast<int>(idx), unique_fd::dup(fd));
    return 0;
}

int Client::on_import_failed(sd_bus_message* m, void* userdata, sd_bus_error*) {
    (void)m;
    auto* w = static_cast<std::weak_ptr<Client>*>(userdata);
    auto self = w->lock();
    if (!self)
        return 0;

    if (self->renderer)
        self->renderer->method_failed();
    return 0;
}
