#pragma once
#if defined(HAVE_LIBSYSTEMD)
#include <systemd/sd-bus.h>
#elif defined(HAVE_LIBELOGIND)
#include <elogind/sd-bus.h>
#endif
#include <cstdint>
#include <vector>
#include <drm/drm_fourcc.h>
#include <thread>
#include <atomic>
#include <mutex>
#include <unordered_map>
#include <memory>
#include <string_view>
#include <numeric>
#include <spdlog/spdlog.h>
#include "mesa/os_time.h"
#include "../server/common/table_structs.h"
#include "client.h"
#include "protocol.h"

class MangoHudServer;
class IPCServer {
public:
    std::vector<std::shared_ptr<Client>> clients;
    std::mutex clients_mtx;
    std::set<int> dead_clients;
    std::mutex dead_clients_mtx;
    MangoHudServer *server;

    IPCServer(MangoHudServer *server_);

    void start();
    bool should_stop();
    void record_server_request();
    void prune_clients();
    std::shared_ptr<Client> focused_client(std::string_view display);
    ~IPCServer();

private:
    sd_bus *bus = nullptr;
    sd_bus_slot *slot = nullptr;
    sd_id128_t server_id;
    std::thread thread;
    std::atomic<bool> stop {false};
    int64_t server_request_time = 0;
    int64_t idle_since = 0;
    std::mutex q_mtx;
    std::deque<sd_bus_message*> msgs;
    std::deque<std::pair<std::string, int>> fences;
    std::deque<std::string> dmabuf_q;
    std::mutex dmabuf_m;
    std::deque<std::string> configs;

    int init();
    void socket_thread();
    int make_socket(const std::string &path);
    void dbus_thread();
    static int on_preflight(sd_bus_message* m, void* userdata, sd_bus_error* ret_error);
    static int on_request_fd(sd_bus_message *m, void *userdata, sd_bus_error*);
    static int on_get_clients(sd_bus_message *m, void *userdata, sd_bus_error*);
    static int on_get_system(sd_bus_message *m, void *userdata, sd_bus_error*);
};
