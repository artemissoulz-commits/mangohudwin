#pragma once

#include <cstdint>
#include <memory>

#include "../gpu.hpp"
#include "../hwmon.hpp"
#include "fdinfo.hpp"

class MSM_GPUMemTrace;

class MSM_DPU : public GPU, private Hwmon, public FDInfo {
private:
    const std::vector<hwmon_sensor> sensors = {
        { "temp", "temp1_input" }
    };

    std::map<pid_t, uint64_t> previous_gpu_times;
    std::ifstream junction_temp_file;
    std::ifstream memory_temp_file;
    std::ifstream core_clock_file;
    std::ifstream load_file;
    std::unique_ptr<MSM_GPUMemTrace> gpu_mem_trace;
    bool steam_frame = false;

    std::ifstream open_thermal_zone(const std::string& type);
    std::ifstream open_core_clock();
    std::ifstream open_load();
    int read_thermal_zone(std::ifstream& file);

protected:
    void pre_poll_overrides() override;

public:
    MSM_DPU(
        const std::string& drm_node, const std::string& pci_dev,
        uint16_t vendor_id, uint16_t device_id
    );
    ~MSM_DPU();

    // System-related functions
    int     get_load()                          override;
    float   get_vram_used()                     override;
    int     get_temperature()                   override;
    int     get_junction_temperature()          override;
    int     get_memory_temp()                   override;
    float   get_memory_total()                  override;
    int     get_memory_clock()                  override;
    int     get_core_clock()                    override;
    float   get_power_usage()                   override;

    // Process-related functions
    int     get_process_load(pid_t pid)         override;
    float   get_process_vram_used(pid_t pid)    override;
};
