#pragma once
#include <EGL/egl.h>
#include <EGL/eglext.h>
#define GL_GLEXT_PROTOTYPES 1
#include <GL/gl.h>
#include <GL/glext.h>
#include <GL/glx.h>

#include <cstdio>
#include <cstring>
#include <sys/stat.h>
#include <dlfcn.h>
#include <thread>
#include <unordered_map>
#include "../ipc/ipc_client.h"
#include "file_utils.h"
#include "../render/shared.h"
#include <VkBootstrap.h>

struct dmabuf {
    GLuint tex = 0;
    GLuint memobj = 0;
    EGLImageKHR image = EGL_NO_IMAGE_KHR;
    EGLDisplay egl_dpy = EGL_NO_DISPLAY;

    dmabuf() {
        glGenTextures(1, &tex);

        glBindTexture(GL_TEXTURE_2D, tex);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    }

    ~dmabuf() {
        if (image != EGL_NO_IMAGE_KHR) {
            if (egl_dpy != EGL_NO_DISPLAY) {
                eglDestroyImage(egl_dpy, image);
            }
            image = EGL_NO_IMAGE_KHR;
            egl_dpy = EGL_NO_DISPLAY;
        }

        if (glXGetCurrentContext()) {
            if (memobj != 0) {
                glDeleteMemoryObjectsEXT(1, &memobj);
                memobj = 0;
            }
            if (tex != 0) {
                glDeleteTextures(1, &tex);
                tex = 0;
            }
        }
    }
};

struct CtxRes {
    GLuint prog = 0;
    GLuint vao = 0;
    GLuint vbo = 0;
    GLuint cache_tex = 0;
    GLuint cache_fbo = 0;
    int cache_w = 0;
    int cache_h = 0;

    GLint uTexLoc = -1;
    GLint uFlipYLoc = -1;
    GLint uDecodeSRGBLoc = -1;
    GLint uSwapRBLoc = -1;

    std::vector<std::unique_ptr<dmabuf>> dmabufs;

    bool inited = false;
};

struct GLState {
    struct state {
        GLint program = 0;
        GLint vao = 0;
        GLint arrayBuf = 0;
        GLint elemBuf = 0;
        GLint activeTex = 0;
        GLint tex2D = 0;
        GLint fbo = 0;
        GLint viewport[4] = {0,0,0,0};

        GLboolean blend = GL_FALSE;
        GLint blendSrcRGB=0, blendDstRGB=0, blendSrcA=0, blendDstA=0;
        GLint pbo = 0, align = 0, rowLen = 0, sampler = 0;
        GLboolean framebufferSRGB = GL_FALSE;

    } saved;

    GLState() {
        saved = save_state();
    }

    ~GLState() {
        restore_state(saved);
    }

    state save_state() {
        state s{};
        glGetIntegerv(GL_CURRENT_PROGRAM, &s.program);
        glGetIntegerv(GL_VERTEX_ARRAY_BINDING, &s.vao);
        glGetIntegerv(GL_ARRAY_BUFFER_BINDING, &s.arrayBuf);
        glGetIntegerv(GL_ELEMENT_ARRAY_BUFFER_BINDING, &s.elemBuf);
        glGetIntegerv(GL_ACTIVE_TEXTURE, &s.activeTex);
        glGetIntegerv(GL_TEXTURE_BINDING_2D, &s.tex2D);
        glGetIntegerv(GL_FRAMEBUFFER_BINDING, &s.fbo);
        glGetIntegerv(GL_VIEWPORT, s.viewport);

        s.blend = glIsEnabled(GL_BLEND);
        s.framebufferSRGB = glIsEnabled(GL_FRAMEBUFFER_SRGB);
        glGetIntegerv(GL_BLEND_SRC_RGB, &s.blendSrcRGB);
        glGetIntegerv(GL_BLEND_DST_RGB, &s.blendDstRGB);
        glGetIntegerv(GL_BLEND_SRC_ALPHA, &s.blendSrcA);
        glGetIntegerv(GL_BLEND_DST_ALPHA, &s.blendDstA);

        glGetIntegerv(GL_PIXEL_UNPACK_BUFFER_BINDING, &s.pbo);
        glGetIntegerv(GL_UNPACK_ALIGNMENT, &s.align);
        glGetIntegerv(GL_UNPACK_ROW_LENGTH, &s.rowLen);

        glBindBuffer(GL_PIXEL_UNPACK_BUFFER, 0);
        glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
        glPixelStorei(GL_UNPACK_ROW_LENGTH, 0);
        glGetIntegeri_v(GL_SAMPLER_BINDING, 0, &s.sampler);
        glBindSampler(0, 0);
        return s;
    }

    void restore_state(const state& s) {
        glUseProgram(s.program);
        glBindVertexArray(s.vao);
        glBindBuffer(GL_ARRAY_BUFFER, s.arrayBuf);
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, s.elemBuf);
        glActiveTexture(s.activeTex);
        glBindTexture(GL_TEXTURE_2D, s.tex2D);
        glBindFramebuffer(GL_FRAMEBUFFER, s.fbo);
        glPixelStorei(GL_UNPACK_ROW_LENGTH, s.rowLen);
        glPixelStorei(GL_UNPACK_ALIGNMENT, s.align);
        glBindSampler(0, s.sampler);
        glBindBuffer(GL_PIXEL_UNPACK_BUFFER, s.pbo);
        glViewport(s.viewport[0], s.viewport[1], s.viewport[2], s.viewport[3]);

        glBlendFuncSeparate(s.blendSrcRGB, s.blendDstRGB, s.blendSrcA, s.blendDstA);
        if (s.blend) glEnable(GL_BLEND);
        else glDisable(GL_BLEND);
        if (s.framebufferSRGB) glEnable(GL_FRAMEBUFFER_SRGB);
        else glDisable(GL_FRAMEBUFFER_SRGB);
    }
};

class EGL {
public:
    EGL();

    int64_t renderer(EGLDisplay dpy = EGL_NO_DISPLAY);
    EGLDisplay import_dmabuf(const Fdinfo& fdinfo, GLuint& tex, EGLImageKHR& image, int f, Display* xdpy = nullptr);

    CtxRes* ctx() {
        EGLContext c = eglGetCurrentContext();
        if (c == EGL_NO_CONTEXT) return nullptr;
        std::lock_guard<std::mutex> lk(ctx_m);
        return &contexts[c];
    }

    void reinit_ctx() {
        std::lock_guard<std::mutex> lk(ctx_m);
        for (auto& [ctx, res] : contexts)
            res.inited = false;
    }

private:
    std::mutex ctx_m;
    std::unordered_map<EGLContext, CtxRes> contexts;
    PFNEGLGETPROCADDRESSPROC            real_eglGetProcAddress          = nullptr;
    PFNEGLDESTROYIMAGEKHRPROC           p_eglDestroyImageKHR            = nullptr;
    PFNGLEGLIMAGETARGETTEXTURE2DOESPROC p_glEGLImageTargetTexture2DOES  = nullptr;
    PFNEGLCREATEIMAGEKHRPROC            p_eglCreateImageKHR             = nullptr;
    PFNEGLQUERYDISPLAYATTRIBEXTPROC     p_eglQueryDisplayAttribEXT      = nullptr;
    PFNEGLQUERYDEVICESTRINGEXTPROC      p_eglQueryDeviceStringEXT       = nullptr;
    PFNEGLGETPLATFORMDISPLAYEXTPROC     p_eglGetPlatformDisplayEXT      = nullptr;
    PFNEGLQUERYDMABUFMODIFIERSEXTPROC   p_eglQueryDmaBufModifiersEXT    = nullptr;
    PFNEGLQUERYDEVICESEXTPROC           p_eglQueryDevicesEXT            = nullptr;

    EGLDisplay display_from_glx(Display* xdpy);
    bool display_supports_modifier(EGLDisplay dpy, uint32_t fourcc, uint64_t modifier);
    EGLDisplay display_from_device_for_modifier(uint32_t fourcc, uint64_t modifier);
};

class GLX {
public:
    GLX();

    bool import_dmabuf(const Fdinfo& fdinfo, GLuint& tex, GLuint& memobj, int f);
    bool import_opaque_fd(GLuint tex, const Fdinfo& fdinfo, GLuint& memobj, int f);

    CtxRes* ctx() {
        GLXContext c = glXGetCurrentContext();
        if (!c) return nullptr;
        std::lock_guard<std::mutex> lk(ctx_m);
        return &contexts[c];
    }

    void reinit_ctx() {
        std::lock_guard<std::mutex> lk(ctx_m);
        for (auto& [ctx, res] : contexts)
            res.inited = false;
    }

private:
    std::mutex ctx_m;
    std::unordered_map<GLXContext, CtxRes> contexts;
    PFNGLCREATEMEMORYOBJECTSEXTPROC     p_glCreateMemoryObjectsEXT = nullptr;
    PFNGLDELETEMEMORYOBJECTSEXTPROC     p_glDeleteMemoryObjectsEXT = nullptr;
    PFNGLIMPORTMEMORYFDEXTPROC          p_glImportMemoryFdEXT      = nullptr;
    PFNGLTEXSTORAGEMEM2DEXTPROC         p_glTexStorageMem2DEXT     = nullptr;

    static const char* gl_err_str(GLenum e);
    static bool drain_gl_errors(const char* where);

    void* glx_gp(const char* name) {
        return (void*)glXGetProcAddress((const GLubyte*)name);
    }
};

class OverlayGL {
public:
    Display* xdpy;
    std::shared_ptr<IPCClient> ipc;
    int current_slot = -1;

    OverlayGL(Display* xdpy_ = nullptr, std::shared_ptr<IPCClient> ipc_ = nullptr);
    CtxRes* get_ctx();
    void draw();

private:
    std::unique_ptr<GLX> glx;
    std::unique_ptr<EGL> egl;
    Fdinfo fdinfo;
    std::string pEngineName = "OpenGL";
    uint32_t w = 0;
    uint32_t h = 0;
    bool inited = false;
    uint64_t imported_generation = 0;

    static GLuint compile_shader(GLenum type, const char *src);
    static GLuint link_program(GLuint vs, GLuint fs);

    void program(CtxRes* r);
    void vao_vbo(CtxRes* r) {
        if (!r->vao) glGenVertexArrays(1, &r->vao);
        if (!r->vbo) glGenBuffers(1, &r->vbo);

        glBindVertexArray(r->vao);
        glBindBuffer(GL_ARRAY_BUFFER, r->vbo);
        glBufferData(GL_ARRAY_BUFFER, 4 * 4 * (GLsizeiptr)sizeof(float), nullptr, GL_STREAM_DRAW);

        glEnableVertexAttribArray(0);
        glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 4 * (GLsizei)sizeof(float), (void*)0);

        glEnableVertexAttribArray(1);
        glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 4 * (GLsizei)sizeof(float), (void*)(2 * sizeof(float)));

        glBindVertexArray(0);
        glBindBuffer(GL_ARRAY_BUFFER, 0);
    }

    void create_cache(CtxRes* r, int w, int h);
    void sample_dmabuf(CtxRes* r, const Fdinfo& fdinfo, int slot, const GLState::state& saved, bool framebuffer_encodes_srgb);
    void draw_dmabuf(CtxRes* r);
    int release_slot_to_server(IPCClient* ipc, int slot, int dmabuf_fd, bool write = false);
    int release_fence(IPCClient* ipc, int slot, int dmabuf_fd, bool write = false);
    bool import_dmabuf(dmabuf* buf, int fd, int opaque) {
        bool imported = false;
        auto r = glx->ctx();
        if (r) {
            if (fdinfo.opaque_size > 0)
                imported = glx->import_opaque_fd(buf->tex, fdinfo, buf->memobj, opaque);
            else
                imported = glx->import_dmabuf(fdinfo, buf->tex, buf->memobj, fd);
        }

        r = egl->ctx();
        if (r)
            buf->egl_dpy = egl->import_dmabuf(fdinfo, buf->tex, buf->image, fd, nullptr);

        if (buf->egl_dpy != EGL_NO_DISPLAY)
            imported = true;

        return imported;
    }
};
