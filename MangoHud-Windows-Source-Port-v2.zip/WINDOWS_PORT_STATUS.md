# Windows port status (development snapshot)

## Source baseline
- Base: `MangoHud-Windows` fork (MangoHud v0.8.3 source in the uploaded archive).
- Existing user's experimental v2 was not blindly overlaid because its partial Windows adaptations are not compatible file-for-file with this fork.
- Fixed repository filenames remain `MangoHud-Windows-Source-Port-v2.zip` and `.github/workflows/build-windows.yml`.

## Changes made in this snapshot
- `src/win/kiero.cpp/.h`: independent method tables for renderer types and typed hook bind/unbind functions.
- `src/proxy/dxgi_proxy.cpp`: lazy system DXGI loading outside `DllMain`; initialization is moved to a background thread with a bounded retry for late-loaded D3D runtime modules.
- `src/meson.build`: removed the legacy `win/main.cpp` bootstrap from the MangoHud Vulkan layer and fixed the output name of the Vulkan DLL to `MangoHud.dll`.
- `src/win/d3d12_hook.cpp`: fence-backed per-backbuffer allocator reuse, a 5-second bounded fence wait, bounded swap-chain buffer handling, cleanup of partial render-target creation, and a fail-safe resize path if the GPU cannot be synchronized.
- `dev/Run-Vulkan-Test.ps1`: writes a UTF-8 manifest without a BOM, scopes Vulkan/MangoHud environment variables to the child process, and restores the PowerShell session environment after exit.
- `dev/package_windows.ps1`: packages PE files with SHA-256 inventory and a `dumpbin /dependents` report when available.
- `src/win/dxgi.cpp`: releases DXGI factory and adapter COM references on all normal paths.
- `dev/check_windows_port.py`: static consistency checks run before compiling.

## Validation boundary
- Static source checks can be run locally without Windows.
- Full compilation must be run by GitHub Actions on `windows-latest` with MSVC.
- Compilation success is not runtime proof. D3D11, D3D12 and Vulkan must be tested separately in real non-protected applications.
- OpenGL has not been ported in this snapshot.
- The proxy now selects one renderer per process to avoid competing hooks on shared DXGI Present/ResizeBuffers targets. It prefers D3D12 when both runtimes are loaded; MANGOHUD_DXGI_API=D3D11 or D3D12 overrides the choice. Mixed-runtime applications still require runtime evaluation.

## Next engineering milestones
1. Confirm the MSVC build and inspect PE exports/dependencies.
2. Validate D3D11 rendering with a small test app.
3. Validate D3D12 rendering with fence/device-loss/resize testing.
4. Validate Vulkan layer registration and rendering.
5. Implement OpenGL Windows backend (separate WGL hook + renderer).
6. Complete GPU metrics and build the installer only after API tests pass.
