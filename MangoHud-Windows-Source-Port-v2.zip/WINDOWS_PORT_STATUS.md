# MangoHud Windows: experimental source port

This branch is **not safe to distribute as a finished application** and is **not functionally validated**.

## Changes
- DirectX12 headers use platform include paths instead of hardcoded Linux MinGW paths.
- Linux-only legacy GPU wrapper and its fdinfo/AMDGPU backends are not linked on Windows. This intentionally means **AMD/Intel telemetry is incomplete**, not secretly implemented. NVIDIA path is left intact but has not been verified.
- Windows config-file monitoring uses a portable filesystem polling implementation instead of Linux inotify.
- Meson uses optional libdrm on Windows.
- Windows-only CI workflow builds sources in MSYS2, never produces a public release.

## Must fix before release
- Implement Windows AMD/Intel GPU metrics using supported APIs and test on physical hardware.
- Audit and test DirectX11/12 and Vulkan injection paths, especially thread lifecycle and anti-cheat restrictions.
- Verify actual runtime operation, dependencies, installer and clean uninstall.
- Check binary architecture and signing; no unverified DLL should be inserted into a game.

## Source Port v2 (2026-11-02)
- Fixed `src/gpu.h` to include `gpu_metrics_util.h` before `nvidia.h`, so that
  `gpu_metrics` and `Throttling` are defined when NVIDIA is declared.
- Removed the recursive `#include "gpu.h"` dependency from `src/nvidia.h`;
  replaced it with the narrower includes required by the NVIDIA interface.
- Fixed an `else` left dangling under `_WIN32` in `GPU::is_apu()`.
- Added explicit standard-library headers in `gpu_metrics_util.h`.
- Added `dev/check_gpu_headers.py`: compile-only checks for both header orders,
  **not** a runtime test and **not** a verified Windows DLL build.

### Known important limitation
`GPUS::GPUS` in `src/gpu.cpp` still discovers cards from Linux's
`/sys/class/drm`; Windows detection and AMD/Intel metrics need a genuine native
implementation. A green GitHub build alone does not make this a working HUD.
