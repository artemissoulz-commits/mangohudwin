# MangoHud for Windows — development port

This repository contains an experimental Windows port based on the MangoHud-Windows fork by Leclowndu93150, with additional work on renderer initialization, DXGI proxy loading, and Direct3D 12 resource synchronization.

**This is development source, not an installer or a release. Do not deploy the proxy DLL into a game directory yet.** The code has not been validated on a Windows machine in this workspace.

## Intended graphics API coverage

| API | Current state in this source snapshot |
|---|---|
| Vulkan | Windows layer target is built by the MSVC workflow; runtime validation still required |
| Direct3D 11 | DXGI proxy + ImGui D3D11 renderer are present; runtime validation required |
| Direct3D 12 | ImGui D3D12 renderer is compiled with MSVC; runtime validation and device-loss testing required |
| OpenGL | Not ported in this snapshot |
| Direct3D 9/10 | Disabled in Kiero configuration |

The Direct3D proxy is an app-local `dxgi.dll`. It should only be tested with a disposable, non-protected test application after a successful build. It is not safe to assume that every game will load it correctly.

## Work in this development branch

- Keep separate Kiero method tables for D3D11 and D3D12 initialization.
- Make the DXGI proxy load the system DXGI library lazily, outside `DllMain`.
- Remove the old `src/win/main.cpp` bootstrap (it created a second `DllMain` and an unmanaged console/thread path).
- Add bounded retry when a launcher creates a DXGI factory before the D3D runtime is loaded.
- Track D3D12 command allocator use with fences, use a bounded wait, and avoid releasing swap-chain resources while the overlay queue is still using them.
- Make the Vulkan shared-library basename deterministic as `MangoHud.dll` for both MSVC and MinGW toolchains.
- Fix adapter enumeration cleanup in the DXGI GPU helper.

## Build

The checked-in GitHub Actions workflow (`.github/workflows/build-windows.yml`) extracts `MangoHud-Windows-Source-Port-v2.zip` from the repository root, runs static source checks, and builds the Windows x64 targets with MSVC. MSVC is required for the ImGui Direct3D 12 backend used by this fork.

The workflow creates a **NO-INSTALAR** preview artifact containing the Vulkan layer, the DXGI proxy, the standalone helper and diagnostic information (binary SHA-256 inventory and PE dependency report). The Vulkan test launcher writes a temporary manifest, limits its environment changes to the current PowerShell process and restores that environment after the test. This package is for controlled testing only.

## Known limitations

- OpenGL has not been ported to Windows in this source snapshot.
- D3D11 and D3D12 hook installation has not yet been runtime-tested against real applications.
- The proxy selects one renderer per process to avoid installing competing MinHook detours on shared DXGI Present/ResizeBuffers targets. It prefers D3D12 when both runtimes are loaded; set MANGOHUD_DXGI_API=D3D11 or D3D12 before launch to override that choice. This heuristic still needs validation in applications that load both runtimes.
- The DXGI proxy exports the factory/debug functions declared in `src/proxy/dxgi_proxy.def`; additional DXGI exports may be required by some applications.
- Intel-specific load/temperature metrics and CPU temperature are not implemented here.
- MangoJuice is a separate submodule and is not bundled in this source ZIP.

## Credits and license

This port is based on the MangoHud-Windows fork by Leclowndu93150 and the upstream MangoHud project by flightlessmango. Original license and notices are retained in `LICENSE`.
