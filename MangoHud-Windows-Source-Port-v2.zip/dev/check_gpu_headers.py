#!/usr/bin/env python3
"""Compile-only regression test for Windows-port GPU header include ordering.

This deliberately mocks just one Vulkan enum; it does NOT test MangoHud linking,
Windows API integration, metrics collection, or runtime safety.
"""
import os
from pathlib import Path
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parent.parent
COMPILER = shutil.which('c++') or shutil.which('g++')
if COMPILER is None:
    raise SystemExit('No C++ compiler available')

with tempfile.TemporaryDirectory(prefix='mangohud-header-') as d:
    d = Path(d)
    vulkan = d / 'vulkan'
    vulkan.mkdir()
    (vulkan / 'vulkan_core.h').write_text('#pragma once\ntypedef int VkPresentModeKHR;\n')
    cases = {
        'gpu_first': '#include "gpu.h"\n#include "nvidia.h"\n',
        'nvidia_first': '#include "nvidia.h"\n#include "gpu.h"\n',
        'metrics_independent': '#include "gpu_metrics_util.h"\n',
    }
    for case, includes in cases.items():
        source = d / f'{case}.cpp'
        source.write_text('#define _WIN32 1\n' + includes + '\nint main(){return 0;}\n')
        command = [COMPILER, '-std=c++20', '-Wall', '-Wextra', '-pedantic',
                   '-fsyntax-only', '-I', str(d), '-I', str(ROOT / 'src'), str(source)]
        run = subprocess.run(command, text=True, capture_output=True)
        if run.returncode:
            print(run.stdout, run.stderr, sep='\n')
            raise SystemExit(f'FAILED: {case}')
        print(f'OK: {case}')
# Exercise the metric-max macro with fields whose types differ (int, float, bool).
with tempfile.TemporaryDirectory(prefix='mangohud-metrics-') as d:
    d = Path(d)
    source = d / 'metrics_max_types.cpp'
    source.write_text(r"""#define _WIN32 1
#include "gpu_metrics_util.h"
gpu_metrics metrics;
gpu_metrics metrics_buffer[METRICS_SAMPLE_COUNT];
int main() {
    GPU_UPDATE_METRIC_MAX(powerLimit);          // float
    GPU_UPDATE_METRIC_MAX(is_power_throttled);  // bool
    GPU_UPDATE_METRIC_MAX(fan_speed);           // int
    return 0;
}
""")
    command = [COMPILER, '-std=c++20', '-Wall', '-Wextra', '-pedantic',
               '-fsyntax-only', '-I', str(ROOT / 'src'), str(source)]
    run = subprocess.run(command, text=True, capture_output=True)
    if run.returncode:
        print(run.stdout, run.stderr, sep='\n')
        raise SystemExit('FAILED: metrics_max_types')
    print('OK: metrics_max_types (float, bool, int)')

print('GPU header smoke checks passed. Full Windows build NOT verified.')
