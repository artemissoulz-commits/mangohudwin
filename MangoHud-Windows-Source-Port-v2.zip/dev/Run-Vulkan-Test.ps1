param(
    [Parameter(Mandatory = $true)]
    [string]$Executable,
    [Parameter(ValueFromRemainingArguments = $true)]
    [string[]]$ApplicationArguments
)

$ErrorActionPreference = 'Stop'
$packageRoot = Split-Path -Parent $PSScriptRoot
$binDir = Join-Path $packageRoot 'bin'
$manifestDir = Join-Path $packageRoot 'vulkan\implicit_layer.d'
$templatePath = Join-Path $manifestDir 'MangoHud.x86_64.json.template'
$manifestPath = Join-Path $manifestDir 'MangoHud.x86_64.json'
$dllPath = Join-Path $binDir 'MangoHud.dll'
$configPath = Join-Path $packageRoot 'config\MangoHud.conf'

foreach ($requiredPath in @($binDir, $templatePath, $dllPath, $configPath)) {
    if (-not (Test-Path -LiteralPath $requiredPath)) {
        throw "Falta un componente del paquete: $requiredPath"
    }
}

$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = [Security.Principal.WindowsPrincipal]::new($identity)
if ($principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw 'Abre PowerShell sin permisos de administrador. Vulkan ignora las rutas VK_* de prueba en procesos elevados.'
}

$resolvedExe = (Resolve-Path -LiteralPath $Executable).Path
$manifest = Get-Content -LiteralPath $templatePath -Raw | ConvertFrom-Json
$manifest.layer.library_path = (Resolve-Path -LiteralPath $dllPath).Path
$manifestJson = $manifest | ConvertTo-Json -Depth 20
# Windows PowerShell 5.1's -Encoding utf8 writes a BOM. Write UTF-8 without BOM
# so the Vulkan loader receives a plain JSON manifest on every supported shell.
$utf8NoBom = [System.Text.UTF8Encoding]::new($false)
[System.IO.File]::WriteAllText($manifestPath, $manifestJson, $utf8NoBom)

# Save the caller's process environment and restore it after the test. These
# variables are inherited only by the test game and are never written globally.
$environmentNames = @(
    'PATH',
    'VK_IMPLICIT_LAYER_PATH',
    'MANGOHUD',
    'MANGOHUD_CONFIGFILE',
    'MANGOHUD_CONFIG',
    'DISABLE_MANGOHUD'
)
$previousEnvironment = @{}
foreach ($name in $environmentNames) {
    $previousEnvironment[$name] = [Environment]::GetEnvironmentVariable($name, 'Process')
}
$previousLocation = Get-Location
$applicationExitCode = 0

try {
    $env:PATH = "$binDir;$env:PATH"
    $env:VK_IMPLICIT_LAYER_PATH = $manifestDir
    $env:MANGOHUD = '1'
    $env:MANGOHUD_CONFIGFILE = $configPath
    $env:MANGOHUD_CONFIG = $configPath
    Remove-Item Env:DISABLE_MANGOHUD -ErrorAction SilentlyContinue

    Write-Host 'Iniciando una prueba Vulkan aislada de MangoHud.' -ForegroundColor Cyan
    Write-Host "Ejecutable: $resolvedExe"
    Write-Host 'La capa no se registra en el sistema ni modifica el Registro de Windows.'

    Set-Location -LiteralPath (Split-Path -Parent $resolvedExe)
    & $resolvedExe @ApplicationArguments
    if ($null -ne $LASTEXITCODE) {
        $applicationExitCode = $LASTEXITCODE
    }
}
finally {
    Set-Location $previousLocation
    foreach ($name in $environmentNames) {
        $value = $previousEnvironment[$name]
        if ($null -eq $value) {
            [Environment]::SetEnvironmentVariable($name, $null, 'Process')
        } else {
            [Environment]::SetEnvironmentVariable($name, $value, 'Process')
        }
    }
}

Write-Host "La aplicación terminó con código: $applicationExitCode"
Write-Host 'Las variables de entorno originales de esta sesión se han restaurado.'
# Do not use `exit`: this script may be dot-sourced or run inside an existing
# PowerShell window, which must remain open after the test.
