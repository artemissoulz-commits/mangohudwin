#!/usr/bin/env python3
"""Static consistency checks for the experimental Windows port.

These checks do not replace a Windows build or runtime tests.
"""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]

def require(condition: bool, message: str) -> None:
    if not condition:
        print(f"FAIL: {message}", file=sys.stderr)
        raise SystemExit(1)
    print(f"PASS: {message}")

meson = (ROOT / "src/meson.build").read_text(encoding="utf-8")
kiero = (ROOT / "src/win/kiero.cpp").read_text(encoding="utf-8")
kiero_h = (ROOT / "src/win/kiero.h").read_text(encoding="utf-8")
proxy = (ROOT / "src/proxy/dxgi_proxy.cpp").read_text(encoding="utf-8")
d3d12 = (ROOT / "src/win/d3d12_hook.cpp").read_text(encoding="utf-8")
dxgi = (ROOT / "src/win/dxgi.cpp").read_text(encoding="utf-8")
manifest = (ROOT / "src/mangohud.json.in").read_text(encoding="utf-8")
vulkan_test = (ROOT / "dev/Run-Vulkan-Test.ps1").read_text(encoding="utf-8")
package_script = (ROOT / "dev/package_windows.ps1").read_text(encoding="utf-8")

require("name_prefix: ''" in meson[meson.find("mangohud_shared_lib = shared_library("):meson.find("# MangoHud standalone overlay")],
        "Vulkan DLL has deterministic MangoHud.dll basename")
require("'win/main.cpp'" not in meson and not (ROOT / "src/win/main.cpp").exists(),
        "legacy second DllMain bootstrap is not compiled or present")
require("bind(RenderType::Enum" in kiero_h and "g_methodsTables" in kiero,
        "Kiero tracks independent renderer method tables")
require("g_hookTargetsByRenderType" in kiero and "hooksIt->second.erase(target)" in kiero,
        "Unbind only disables hooks owned by that renderer")
require("InitOnceExecuteOnce" in proxy and "LoadLibraryA(path.c_str())" in proxy,
        "system DXGI is loaded lazily through INIT_ONCE")
require("MANGOHUD_DXGI_API" in proxy and "forceD3D12" in proxy and "if (!hasD3D12 && hasD3D11)" in proxy,
        "DXGI proxy selects one renderer to avoid competing Present hooks")
dllmain = proxy[proxy.rfind("BOOL WINAPI DllMain"):]
dllmain_code = re.sub(r"/\*.*?\*/|//[^\n]*", "", dllmain, flags=re.S)
require("ensureRealDXGI" not in dllmain_code and "CreateThread" not in dllmain_code and "LoadLibrary" not in dllmain_code,
        "DXGI proxy DllMain does not load libraries or create threads")
require("wait_for_gpu_idle" in d3d12 and "d3d12FenceValues" in d3d12 and "d3d12FenceFailed" in d3d12,
        "D3D12 overlay tracks in-flight work with fences")
require("QueryInterface(__uuidof(IDXGISwapChain3)" in d3d12 and "GetCurrentBackBufferIndex" in d3d12,
        "D3D12 requests IDXGISwapChain3 before using its extended vtable")
require("factory->Release()" in dxgi and "adapter->Release()" in dxgi,
        "DXGI adapter enumeration releases COM objects")
require('"library_path": "@ld_libdir_mangohud_abs@/MangoHud.dll"' in manifest,
        "Vulkan manifest points to deterministic MangoHud.dll")
require("files('proxy/dxgi_proxy.cpp')" in meson and "vs_module_defs: 'proxy/dxgi_proxy.def'" in meson,
        "DXGI proxy target and export definition remain part of build")
require("FENCE_WAIT_TIMEOUT_MS = 5000" in d3d12 and "FENCE_WAIT_TIMEOUT_MS)" in d3d12,
        "D3D12 fence wait is bounded to avoid an indefinite game hang")
require("SetEnvironmentVariable($name, $value, 'Process')" in vulkan_test and "exit $applicationExitCode" not in vulkan_test,
        "Vulkan test launcher restores its caller environment without exiting PowerShell")
require("UTF8Encoding]::new($false)" in vulkan_test,
        "Vulkan manifest is written as UTF-8 JSON without a BOM")
require("binary-inventory.json" in package_script and "pe-dependencies.txt" in package_script,
        "Preview package includes binary hashes and PE dependency diagnostics")


# MSVC compatibility checks for errors found in GitHub Actions run 43246245280.
macros = (ROOT / "src/mesa/util/macros.h").read_text(encoding="utf-8")
hud = (ROOT / "src/hud_elements.cpp").read_text(encoding="utf-8")
root_meson = (ROOT / "meson.build").read_text(encoding="utf-8")
require("#if defined(_MSC_VER)\n#define PUBLIC __declspec(dllexport)" in macros,
        "Vulkan exported entry points use __declspec(dllexport) with MSVC")
require("pre_args += '-DNOMINMAX'" in root_meson,
        "Windows build disables min/max macros before standard-library calls")
require(not re.search(r"case\s+[-\w]+\s*\.\.\.\s*[-\w]+", hud),
        "Windows-compiled HUD code does not use GCC case-range extensions")


print("All static Windows-port checks passed. This is not a runtime test.")
