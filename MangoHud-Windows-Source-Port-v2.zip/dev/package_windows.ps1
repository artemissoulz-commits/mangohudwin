param(
    [string]$BuildDirectory = 'build-msvc',
    [string]$PackageDirectory = 'package'
)

$ErrorActionPreference = 'Stop'
$repoRoot = (Get-Location).Path
$buildOut = Join-Path $repoRoot (Join-Path $BuildDirectory 'src')
$packageRoot = Join-Path $repoRoot $PackageDirectory
$required = @(
    (Join-Path $buildOut 'MangoHud.dll'),
    (Join-Path $buildOut 'dxgi.dll'),
    (Join-Path $buildOut 'MangoHud.exe'),
    (Join-Path $buildOut 'MangoHud.x86_64.json')
)
foreach ($file in $required) {
    if (-not (Test-Path -LiteralPath $file)) {
        throw "No se ha generado un archivo obligatorio: $file"
    }
}

Remove-Item -LiteralPath $packageRoot -Recurse -Force -ErrorAction SilentlyContinue
$directories = @(
    'bin', 'DirectX', 'tools', 'config', 'vulkan\implicit_layer.d', 'scripts', 'diagnostics'
)
foreach ($directory in $directories) {
    New-Item -ItemType Directory -Path (Join-Path $packageRoot $directory) -Force | Out-Null
}

Copy-Item -LiteralPath (Join-Path $buildOut 'MangoHud.dll') -Destination (Join-Path $packageRoot 'bin\MangoHud.dll')
Copy-Item -LiteralPath (Join-Path $buildOut 'dxgi.dll') -Destination (Join-Path $packageRoot 'DirectX\dxgi.dll')
Copy-Item -LiteralPath (Join-Path $buildOut 'MangoHud.exe') -Destination (Join-Path $packageRoot 'tools\MangoHud.exe')
Copy-Item -LiteralPath (Join-Path $repoRoot 'data\MangoHud.conf') -Destination (Join-Path $packageRoot 'config\MangoHud.conf')
Copy-Item -LiteralPath (Join-Path $repoRoot 'dev\Run-Vulkan-Test.ps1') -Destination (Join-Path $packageRoot 'scripts\Run-Vulkan-Test.ps1')

$manifest = Get-Content -LiteralPath (Join-Path $buildOut 'MangoHud.x86_64.json') -Raw | ConvertFrom-Json
$manifest.layer.library_path = '@MANGOHUD_DLL_PATH_SET_BY_RUN_SCRIPT@'
$templatePath = Join-Path $packageRoot 'vulkan\implicit_layer.d\MangoHud.x86_64.json.template'
$manifest | ConvertTo-Json -Depth 20 | Set-Content -LiteralPath $templatePath -Encoding utf8

$readme = @'
MANGOHUD WINDOWS — EXPERIMENTAL PREVIEW (NO INSTALAR)

This is a development package, not a production installer. Keep the files in this folder.
Do not copy the DXGI proxy into a protected multiplayer game or anti-cheat game.

CONTENTS
- bin\MangoHud.dll: Vulkan layer DLL.
- vulkan\implicit_layer.d\MangoHud.x86_64.json.template: manifest template.
- DirectX\dxgi.dll: app-local DirectX proxy (experimental).
- tools\MangoHud.exe: standalone helper binary.
- scripts\Run-Vulkan-Test.ps1: launches one Vulkan executable with a temporary layer path.
- config\MangoHud.conf: default configuration.

VULKAN TEST (does not write to the Windows Registry)
1. Open PowerShell normally, not as Administrator.
2. Run:
   .\scripts\Run-Vulkan-Test.ps1 -Executable "C:\full\path\to\VulkanApp.exe"
3. The script sets environment variables only for that process and its child process.

DIRECTX TEST
The DirectX proxy has not yet passed runtime validation. Do not install it globally.
For a controlled test, a copy of DirectX\dxgi.dll may be placed beside a disposable test application's EXE, then removed after the test. Do not use this with anti-cheat games.
If a process loads both D3D11 and D3D12, the proxy prefers D3D12. To force a renderer, set MANGOHUD_DXGI_API=D3D11 or MANGOHUD_DXGI_API=D3D12 before launching the test application.

SUPPORT STATUS
Vulkan: build target present; runtime validation pending.
Direct3D 11: hook and ImGui backend present; runtime validation pending.
Direct3D 12: MSVC backend build target present; runtime validation pending.
OpenGL: not ported in this snapshot.
Intel load/temperature and CPU temperature: incomplete.

A green GitHub build means the code compiled and was packaged. It does not prove every graphics API works in games.
'@
Set-Content -LiteralPath (Join-Path $packageRoot 'README-EXPERIMENTAL.txt') -Value $readme -Encoding utf8

# Save exact build metadata for issue reports and diagnostics.
$metadata = @{
    BuildToolchain = 'MSVC x64'
    BuildDirectory = $BuildDirectory
    SourceVersion = 'MangoHud-Windows development port'
    BuiltAtUtc = (Get-Date).ToUniversalTime().ToString('o')
    RuntimeValidated = $false
    GraphicsAPIs = @('Vulkan build target', 'Direct3D 11 build target', 'Direct3D 12 MSVC build target')
    OpenGL = 'Not ported'
}
$metadata | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $packageRoot 'diagnostics\build-info.json') -Encoding utf8

$binaryPaths = @(
    (Join-Path $packageRoot 'bin\MangoHud.dll'),
    (Join-Path $packageRoot 'DirectX\dxgi.dll'),
    (Join-Path $packageRoot 'tools\MangoHud.exe')
)
$inventory = foreach ($binary in $binaryPaths) {
    $item = Get-Item -LiteralPath $binary
    $hash = Get-FileHash -LiteralPath $binary -Algorithm SHA256
    [pscustomobject]@{
        File = $item.Name
        RelativePath = $binary.Substring($packageRoot.Length + 1)
        SizeBytes = $item.Length
        SHA256 = $hash.Hash
    }
}
$inventory | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $packageRoot 'diagnostics\binary-inventory.json') -Encoding utf8

$dumpbin = Get-Command dumpbin.exe -ErrorAction SilentlyContinue
if ($dumpbin) {
    $dependencyReport = Join-Path $packageRoot 'diagnostics\pe-dependencies.txt'
    foreach ($binary in $binaryPaths) {
        Add-Content -LiteralPath $dependencyReport -Value "===== $binary ====="
        & $dumpbin.Source /dependents $binary 2>&1 | Add-Content -LiteralPath $dependencyReport
        Add-Content -LiteralPath $dependencyReport -Value ''
    }
} else {
    Set-Content -LiteralPath (Join-Path $packageRoot 'diagnostics\pe-dependencies.txt') -Value 'dumpbin.exe was not found in PATH; dependency report was not generated.' -Encoding utf8
}

Write-Host "Package prepared: $packageRoot"
