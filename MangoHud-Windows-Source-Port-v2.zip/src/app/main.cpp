// Dear ImGui: standalone example application for GLFW + OpenGL 3, using programmable pipeline
// (GLFW is a cross-platform general purpose library for handling windows, inputs, OpenGL/Vulkan/Metal graphics context creation, etc.)
// If you are new to Dear ImGui, read documentation from the docs/ folder + read the top of imgui.cpp.
// Read online: https://github.com/ocornut/imgui/tree/master/docs

#include <sys/ipc.h>
#include <sys/msg.h>

#include "imgui.h"
#include "imgui_impl_glfw.h"
#include "imgui_impl_opengl3.h"
#include <stdio.h>
#include <thread>
#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <string_view>
#include <unistd.h>
#include "../overlay.h"
#include "notify.h"
#include "mangoapp.h"
#include "mangoapp_proto.h"
#include <GLFW/glfw3.h>
#ifdef __linux__
#include "implot.h"
#endif

#define GLFW_EXPOSE_NATIVE_X11
#include <GLFW/glfw3native.h>
#include <X11/Xatom.h>
#include <X11/Xlib.h>
#include <X11/extensions/XInput2.h>
#include <poll.h>
#include "shared_x11.h"

using namespace std;

static void glfw_error_callback(int error, const char* description)
{
    fprintf(stderr, "Glfw Error %d: %s\n", error, description);
}

static long mangoapp_msg_type()
{
    const char* env = getenv("MANGOAPP_MSG_TYPE");
    if (env) {
        long type = atol(env);
        if (type > 0 && type <= INT32_MAX)
            return type;
    }

    return 1;
}

// gamescope relays mangohudctl's messages onto the stream type plus one.
static long mangoapp_ctrl_msg_type()
{
    long type = mangoapp_msg_type();
    return type == 1 ? 2 : type + 1;
}

static const char* mangoapp_upscaler_name(uint8_t upscaler, const char* fallback)
{
    switch (upscaler) {
        case MANGOAPP_UPSCALER_LINEAR:  return "SCALING";
        case MANGOAPP_UPSCALER_NEAREST: return "NEAREST";
        case MANGOAPP_UPSCALER_FSR:     return "FSR";
        case MANGOAPP_UPSCALER_NIS:     return "NIS";
        case MANGOAPP_UPSCALER_PIXEL:   return "PIXEL";
        case MANGOAPP_UPSCALER_SGSR:    return "SGSR";
        default:                        return fallback;
    }
}

static bool mangoapp_upscaler_sharpens(uint8_t upscaler)
{
    return upscaler == MANGOAPP_UPSCALER_FSR ||
           upscaler == MANGOAPP_UPSCALER_NIS ||
           upscaler == MANGOAPP_UPSCALER_SGSR;
}

static EngineTypes mangoapp_engine_type(std::string_view engine_name)
{
    if (engine_name == "DXVK")
        return EngineTypes::DXVK;
    if (engine_name == "vkd3d")
        return EngineTypes::VKD3D;
    if (engine_name == "mesa zink")
        return EngineTypes::ZINK;
    if (engine_name == "Damavand")
        return EngineTypes::DAMAVAND;
    if (engine_name == "Feral3D")
        return EngineTypes::FERAL3D;
    if (engine_name == "SDLGPU")
        return EngineTypes::SDL;

    return EngineTypes::GAMESCOPE;
}

swapchain_stats sw_stats {};
overlay_params params {};
static ImVec2 window_size;
static uint32_t vendorID;
static std::string deviceName;
static notify_thread notifier;
static int msgid;
static bool mangoapp_paused = false;
std::mutex mangoapp_m;
std::condition_variable mangoapp_cv;
static uint8_t raw_msg[1024] = {0};
static uint32_t screenWidth, screenHeight;
static std::atomic_bool g_x_dead{false};

static int x_error_handler(Display* dpy, XErrorEvent* event) {
    g_x_dead.store(true);

    char error_text[256] = "unknown";
    if (dpy)
        XGetErrorText(dpy, event->error_code, error_text, sizeof(error_text));
    fprintf(stderr, "mangoapp: X11 error %u (%s), request %u.%u, resource 0x%lx\n",
            event->error_code, error_text, event->request_code, event->minor_code, event->resourceid);

    return 0;
}

static int x_io_error_handler(Display*) {
    _exit(0);
}

static bool x_connection_ok(Display* dpy) {
    if (!dpy)
        return false;

    int fd = XConnectionNumber(dpy);
    if (fd < 0)
        return false;

    pollfd p{fd, 0, 0};
    if (poll(&p, 1, 0) < 0)
        return false;

    return (p.revents & (POLLERR | POLLHUP | POLLNVAL)) == 0;
}

static bool set_x_cardinal_property(Display* dpy, Window window, Atom property, uint32_t value) {
    if (g_x_dead.load() || !window || !x_connection_ok(dpy)) {
        g_x_dead.store(true);
        return false;
    }

    XChangeProperty(dpy, window, property, XA_CARDINAL, 32, PropModeReplace,
                    (unsigned char *)&value, 1);
    XSync(dpy, 0);

    return !g_x_dead.load();
}

static unsigned int get_prop(const char* propName){
    if (g_x_dead.load())
        return -1;

    Display *x11_display = glfwGetX11Display();
    // Make sure Xorg display is still there before continuing
    if (!x_connection_ok(x11_display)) {
        g_x_dead.store(true);
        return -1;
    }

    Atom gamescope_focused = XInternAtom(x11_display, propName, false);
    auto scr = DefaultScreen(x11_display);
    auto root = RootWindow(x11_display, scr);
    Atom actual;
    int format;
    unsigned long n, left;
    uint64_t *data;
    int result = XGetWindowProperty(x11_display, root, gamescope_focused, 0L, 1L, false,
                            XA_CARDINAL, &actual, &format,
                            &n, &left, ( unsigned char** )&data);

    if (result == Success && data != NULL){
        unsigned int i;
        memcpy(&i, data, sizeof(unsigned int));
        XFree((void *) data);
        return i;
    }
    return -1;
}

static int xi_opcode = -1;
static char key_state[32];
static unsigned long key_state_serial;

// Use the keybind connection so GLFW cannot consume these events.
static bool init_key_events() {
    if (!init_x11())
        return false;

    Display *dpy = get_xdisplay();
    int event, error;
    if (!XQueryExtension(dpy, "XInputExtension", &xi_opcode, &event, &error))
        return false;

    int major = 2, minor = 2;
    return XIQueryVersion(dpy, &major, &minor) == Success;
}

// Raw events detect key presses even when another window has focus.
static void select_key_events(bool enable) {
    Display *dpy = get_xdisplay();
    unsigned char mask[XIMaskLen(XI_RawKeyRelease)] = {};
    if (enable) {
        XISetMask(mask, XI_RawKeyPress);
        XISetMask(mask, XI_RawKeyRelease);
    }

    XIEventMask event_mask = { XIAllMasterDevices, sizeof(mask), mask };
    XISelectEvents(dpy, DefaultRootWindow(dpy), &event_mask, 1);
    if (!enable) {
        XFlush(dpy);
        return;
    }

    // Skip events already reflected in the initial keymap.
    key_state_serial = NextRequest(dpy);
    XQueryKeymap(dpy, key_state);
}

// Replay key state so short taps still count after their keys are released.
static void handle_key_events(int timeout_ms, overlay_params& params) {
    Display *dpy = get_xdisplay();
    // Check Xlib's queue before polling to avoid sleeping through queued events.
    if (!XPending(dpy)) {
        pollfd p{XConnectionNumber(dpy), POLLIN, 0};
        if (poll(&p, 1, timeout_ms) > 0 && (p.revents & (POLLERR | POLLHUP | POLLNVAL))) {
            g_x_dead.store(true);
            return;
        }
    }

    while (XPending(dpy)) {
        XEvent ev;
        XNextEvent(dpy, &ev);
        XGenericEventCookie *cookie = &ev.xcookie;
        if (cookie->type != GenericEvent || cookie->extension != xi_opcode ||
            cookie->serial < key_state_serial || !XGetEventData(dpy, cookie))
            continue;

        int keycode = ((XIRawEvent *)cookie->data)->detail;
        if (keycode >= 0 && keycode < 256) {
            if (cookie->evtype == XI_RawKeyPress) {
                key_state[keycode >> 3] |= 1 << (keycode & 7);
                check_keybinds(params, key_state);
            } else if (cookie->evtype == XI_RawKeyRelease) {
                key_state[keycode >> 3] &= ~(1 << (keycode & 7));
            }
        }
        XFreeEventData(dpy, cookie);
    }
}

static void ctrl_thread(){
    // Own buffer, msg_read_thread is reading into raw_msg at the same time.
    static uint8_t ctrl_msg[1024] = {0};
    const long ctrl_msg_type = mangoapp_ctrl_msg_type();

    while (1){
        const struct mangoapp_ctrl_msgid1_v1 *mangoapp_ctrl_v1 = (const struct mangoapp_ctrl_msgid1_v1*) ctrl_msg;
        memset(ctrl_msg, 0, sizeof(ctrl_msg));
        msgrcv(msgid, (void *) ctrl_msg, sizeof(ctrl_msg), ctrl_msg_type, 0);
        switch (mangoapp_ctrl_v1->log_session) {
            case 0:
                // Keep as-is
                break;
            case 1:
                if (!logger->is_active())
                    logger->start_logging();
                break;
            case 2:
                if (logger->is_active())
                    logger->stop_logging();
                break;
            case 3:
                logger->is_active() ? logger->stop_logging() : logger->start_logging();
                break;
        }
        switch (mangoapp_ctrl_v1->reload_config) {
            case 0:
                break;
            case 1:
                parse_overlay_config(&params, getenv("MANGOHUD_CONFIG"), false);
                break;
            case 2:
                break;
            case 3:
                parse_overlay_config(&params, getenv("MANGOHUD_CONFIG"), false);
                break;
        }
        {
            std::lock_guard<std::mutex> lk(mangoapp_m);
            auto real_params = get_params();
            switch (mangoapp_ctrl_v1->no_display){
                case 0:
                    // Keep as-is
                    break;
                case 1:
                    real_params->no_display = 1;
                    break;
                case 2:
                    real_params->no_display = 0;
                    break;
                case 3:
                    real_params->no_display ? real_params->no_display = 0 : real_params->no_display = 1;
                    break;
            }
        }
        mangoapp_cv.notify_one();
    }
}

bool new_frame = false;

static void gamescope_frametime(uint64_t app_frametime_ns, uint64_t latency_ns){
    if (app_frametime_ns != uint64_t(-1))
    {
        float app_frametime_ms = app_frametime_ns / 1000000.f;
        HUDElements.gamescope_debug_app.push_back(app_frametime_ms);
        if (HUDElements.gamescope_debug_app.size() > 200)
            HUDElements.gamescope_debug_app.erase(HUDElements.gamescope_debug_app.begin());
    }

    float latency_ms = latency_ns / 1000000.f;
    if (latency_ns == uint64_t(-1))
        latency_ms = -1;
    HUDElements.gamescope_debug_latency.push_back(latency_ms);
    if (HUDElements.gamescope_debug_latency.size() > 200)
        HUDElements.gamescope_debug_latency.erase(HUDElements.gamescope_debug_latency.begin());
}

static void msg_read_thread(){
    for (size_t i = 0; i < 200; i++){
        HUDElements.gamescope_debug_app.push_back(0);
        HUDElements.gamescope_debug_latency.push_back(0);
    }
    int key = ftok("mangoapp", 65);
    msgid = msgget(key, 0666 | IPC_CREAT);
    // uint32_t previous_pid = 0;
    const struct mangoapp_msg_header *hdr = (const struct mangoapp_msg_header*) raw_msg;
    const struct mangoapp_msg_v1 *mangoapp_v1 = (const struct mangoapp_msg_v1*) raw_msg;

    uint32_t previous_game_pid = 0;
    const long msg_type = mangoapp_msg_type();

    while (1){
        // make sure that the message recieved is compatible
        // and that we're not trying to use variables that don't exist (yet)
        size_t msg_size = msgrcv(msgid, (void *) raw_msg, sizeof(raw_msg), msg_type, 0);
        if (msg_size != size_t(-1))
        {
            if (hdr->version == 1){
                // msgrcv's size excludes msg_type, which offsetof counts.
                const size_t msg_bytes = msg_size + sizeof(hdr->msg_type);

                if (msg_bytes > offsetof(struct mangoapp_msg_v1, pid)) {
                    HUDElements.g_gamescopePid = mangoapp_v1->pid;

                    if (previous_game_pid != mangoapp_v1->pid) {
                        previous_game_pid = mangoapp_v1->pid;
                        check_for_vkbasalt_and_gamemode();
                    }
                }

                if (msg_bytes > offsetof(struct mangoapp_msg_v1, visible_frametime_ns)){
                    auto real_params = get_params();
                    bool should_new_frame = false;
                    if (mangoapp_v1->visible_frametime_ns != ~(0lu) && (!real_params->no_display || logger->is_active())) {
                        update_hud_info_with_frametime(sw_stats, params, vendorID, mangoapp_v1->visible_frametime_ns);
                        should_new_frame = true;
                    }

                    if (msg_bytes > offsetof(mangoapp_msg_v1, fsrUpscale)){
                        HUDElements.g_fsrUpscale = mangoapp_v1->fsrUpscale;
                        if (real_params->fsr_steam_sharpness < 0)
                            HUDElements.g_fsrSharpness = mangoapp_v1->fsrSharpness;
                        else
                        HUDElements.g_fsrSharpness = real_params->fsr_steam_sharpness - mangoapp_v1->fsrSharpness;
                    }
                    uint8_t upscaler = mangoapp_v1->fsrUpscale ? MANGOAPP_UPSCALER_FSR : MANGOAPP_UPSCALER_LINEAR;
                    if (msg_bytes > offsetof(mangoapp_msg_v1, upscaler))
                        upscaler = mangoapp_v1->upscaler;

                    uint8_t wanted_upscaler = upscaler;
                    if (upscaler == MANGOAPP_UPSCALER_LINEAR)
                        wanted_upscaler = MANGOAPP_UPSCALER_FSR;
                    if (msg_bytes > offsetof(mangoapp_msg_v1, wantedUpscaler))
                        wanted_upscaler = mangoapp_v1->wantedUpscaler;

                    HUDElements.g_upscaler = mangoapp_upscaler_name(upscaler, "LINEAR");
                    HUDElements.g_wantedUpscaler = mangoapp_upscaler_name(wanted_upscaler, "SCALING");
                    HUDElements.g_upscaling = upscaler != MANGOAPP_UPSCALER_LINEAR;
                    HUDElements.g_upscalerSharpens = mangoapp_upscaler_sharpens(upscaler);
                    if (!real_params->enabled[OVERLAY_PARAM_ENABLED_mangoapp_steam]){
                        steam_focused = get_prop("GAMESCOPE_FOCUSED_APP_GFX") == 769;
                    } else {
                        steam_focused = false;
                    }

                    if (msg_bytes > offsetof(mangoapp_msg_v1, engineName) && !steam_focused) {
                        sw_stats.engineName = std::string(mangoapp_v1->engineName, strnlen(mangoapp_v1->engineName, sizeof(mangoapp_v1->engineName)));
                        sw_stats.engine = mangoapp_engine_type(sw_stats.engineName);
                    } else {
                        sw_stats.engineName = "GAMESCOPE";
                        sw_stats.engine = EngineTypes::GAMESCOPE;
                    }

                    if (msg_bytes > offsetof(mangoapp_msg_v1, latency_ns))
                        gamescope_frametime(mangoapp_v1->app_frametime_ns, mangoapp_v1->latency_ns);

                    if (msg_bytes > offsetof(mangoapp_msg_v1, scanoutRefreshmHz))
                        HUDElements.scanout_refresh = mangoapp_v1->scanoutRefreshmHz / 1000.f;

                    if (should_new_frame)
                    {
                        {
                            std::unique_lock<std::mutex> lk(mangoapp_m);
                            new_frame = true;
                        }
                        mangoapp_cv.notify_one();
                        screenWidth = mangoapp_v1->outputWidth;
                        screenHeight = mangoapp_v1->outputHeight;
                    }
                }
            } else {
                printf("Unsupported mangoapp struct version: %i\n", hdr->version);
            }
        }
        else
        {
            printf("mangoapp: msgrcv returned -1 with error %d - %s\n", errno, strerror(errno));
        }
    }
}

static const char *GamescopeOverlayProperty = "GAMESCOPE_EXTERNAL_OVERLAY";

static GLFWwindow* init(const char* glsl_version){
    init_spdlog();
    GLFWwindow *window = glfwCreateWindow(1280, 800, "mangoapp overlay window", NULL, NULL);
    Display *x11_display = glfwGetX11Display();
    Window x11_window = glfwGetX11Window(window);
    if (x11_window && x11_display)
    {
        // Set atom for gamescope to render as an overlay.
        const long msg_type = mangoapp_msg_type();
        if (msg_type != 1) {
            // Tag before the overlay property.
            Atom msg_type_atom = XInternAtom(x11_display, "GAMESCOPE_MANGOAPP_MSG_TYPE", False);
            set_x_cardinal_property(x11_display, x11_window, msg_type_atom, msg_type);
        }

        Atom overlay_atom = XInternAtom (x11_display, GamescopeOverlayProperty, False);
        uint32_t value = 1;
        set_x_cardinal_property(x11_display, x11_window, overlay_atom, value);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1); // Enable vsync
    ImGui::CreateContext();
#ifdef __linux__
    ImPlot::CreateContext();
#endif
    ImGuiIO& io = ImGui::GetIO(); (void)io;
    io.IniFilename = NULL;
    ImGui::StyleColorsDark();
    ImGui_ImplGlfw_InitForOpenGL(window, true);
    ImGui_ImplOpenGL3_Init(glsl_version);
    return window;
}

static void shutdown(GLFWwindow* window){
    ImGui_ImplOpenGL3_Shutdown();
    ImGui_ImplGlfw_Shutdown();
    ImGui::DestroyContext();
    glfwDestroyWindow(window);
}

static void get_atom_info(){
    HUDElements.hdr_status = get_prop("GAMESCOPE_COLOR_APP_WANTS_HDR_FEEDBACK");
    HUDElements.refresh = get_prop("GAMESCOPE_DISPLAY_REFRESH_RATE_FEEDBACK");
}

static bool render(GLFWwindow* window, overlay_params& real_params) {
    if (HUDElements.colors.update)
        HUDElements.convert_colors(params);

    if (sw_stats.font_params_hash != params.font_params_hash)
    {
        sw_stats.font_params_hash = params.font_params_hash;
        create_fonts(nullptr, params, sw_stats.font_small, sw_stats.font_text, sw_stats.font_secondary);
        ImGui_ImplOpenGL3_CreateFontsTexture();
    }
    ImGui_ImplGlfw_NewFrame();
    ImGui_ImplOpenGL3_NewFrame();
    ImGui::NewFrame();
    overlay_new_frame(real_params);
    position_layer(sw_stats, real_params, window_size);
    render_imgui(sw_stats, real_params, window_size, true);
    get_atom_info();
    overlay_end_frame();
    static bool window_size_changed = false;
    int w, h;
    glfwGetWindowSize(window, &w, &h);
    window_size_changed = w != window_size.x || h != window_size.y;
    if (real_params.enabled[OVERLAY_PARAM_ENABLED_horizontal])
    // trying to reduce height will break direct scanout in some cases
    // just leave it for now, we'll revisit it in server
    glfwSetWindowSize(window, screenWidth, screenHeight);

    ImGui::EndFrame();

    return window_size_changed;
}

int main(int, char**)
{
    XInitThreads();
    XSetErrorHandler(x_error_handler);
    XSetIOErrorHandler(x_io_error_handler);

    // Setup window
    glfwSetErrorCallback(glfw_error_callback);
    if (!glfwInit())
        return 1;

    const char* glsl_version = "#version 130";
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 0);

    glfwWindowHint(GLFW_RESIZABLE, 1);
    glfwWindowHint(GLFW_TRANSPARENT_FRAMEBUFFER, 1);
    glfwWindowHint(GLFW_DEPTH_BITS,   0);
    glfwWindowHint(GLFW_STENCIL_BITS, 0);

    // Create window with graphics context
    GLFWwindow* window = init(glsl_version);

    Display *x11_display = glfwGetX11Display();
    Window x11_window = glfwGetX11Window(window);
    Atom overlay_atom = XInternAtom (x11_display, GamescopeOverlayProperty, False);

    // Setup Platform/Renderer backends
    int control_client = -1;
    parse_overlay_config(&params, getenv("MANGOHUD_CONFIG"), false);
    create_fonts(nullptr, params, sw_stats.font_small, sw_stats.font_text, sw_stats.font_secondary);
    HUDElements.convert_colors(params);
    init_cpu_stats(params);
    notifier.params = &params;
    start_notifier(notifier);
    auto real_params = get_params();
    window_size = ImVec2(real_params->width, real_params->height);
    deviceName = (char*)glGetString(GL_RENDERER);
    sw_stats.deviceName = deviceName;
    SPDLOG_DEBUG("mangoapp deviceName: {}", deviceName);
    #define GLX_RENDERER_VENDOR_ID_MESA 0x8183
    auto pfn_glXQueryCurrentRendererIntegerMESA = (Bool (*)(int, unsigned int*)) (glfwGetProcAddress("glXQueryCurrentRendererIntegerMESA"));
    // This will return 0x0 vendorID on NVIDIA so just go to else
    if (pfn_glXQueryCurrentRendererIntegerMESA && vendorID != 0x0) {
        pfn_glXQueryCurrentRendererIntegerMESA(GLX_RENDERER_VENDOR_ID_MESA, &vendorID);
        SPDLOG_DEBUG("mangoapp vendorID: {:#x}", vendorID);
    } else {
        if (deviceName.find("Radeon") != std::string::npos
        || deviceName.find("AMD") != std::string::npos){
            vendorID = 0x1002;
        } else if (deviceName.find("Intel") != std::string::npos) {
            vendorID = 0x8086;
        } else {
            vendorID = 0x10de;
        }
    }

    HUDElements.vendorID = vendorID;
    init_system_info();
    sw_stats.engine = EngineTypes::GAMESCOPE;
    std::thread(msg_read_thread).detach();
    std::thread(ctrl_thread).detach();
    const bool key_events = init_key_events();
    if (!logger) logger = std::make_unique<Logger>(&params);
    if (!g_x_dead.load()) {
        Atom noFocusAtom = XInternAtom(x11_display, "GAMESCOPE_NO_FOCUS", False);
        uint32_t value = 1;
        set_x_cardinal_property(x11_display, x11_window, noFocusAtom, value);
    }
    // Main loop
    while (true){
        if (g_x_dead.load() || glfwWindowShouldClose(window))
            break;

        real_params = get_params();
        check_keybinds(*real_params);
        if (!real_params->no_display){
            if (mangoapp_paused){
                glfwShowWindow(window);
                render(window, *real_params);
                uint32_t value = 1;
                set_x_cardinal_property(x11_display, x11_window, overlay_atom, value);
                mangoapp_paused = false;
                if (key_events)
                    select_key_events(false);
                // resume all GPU threads
                if (gpus)
                    for (auto gpu : gpus->available_gpus)
                        gpu->resume();
            }

            // throttle to one render per game frame, else we render flat-out
            {
                std::unique_lock<std::mutex> lk(mangoapp_m);
                mangoapp_cv.wait_for(lk, std::chrono::milliseconds(100), [&] {
                    return new_frame || real_params->no_display;
                });
                // no_display can flip mid-wait so re-check
                if (real_params->no_display || !new_frame)
                    continue;
                new_frame = false;
            }

            {
                if (render(window, *real_params)) {
                    // If we need to resize our window, give it another couple of rounds for the
                    // stupid display size stuff to propagate through ImGUI (using NDC and scaling
                    // in GL makes me a very unhappy boy.)
                    render(window, *real_params);
                    render(window, *real_params);
                }

                if (real_params->control >= 0) {
                    control_client_check(real_params->control, control_client, deviceName);
                    process_control_socket(control_client, params);
                }
            }
            // Rendering
            ImGui::Render();
            glEnable(GL_DEPTH_TEST);
            glEnable(GL_BLEND);
            glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
            glClearColor(0, 0, 0, 0);
            glClear(GL_COLOR_BUFFER_BIT);
            ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());

            glfwSwapBuffers(window);
        } else if (!mangoapp_paused) {
            glClearColor(0, 0, 0, 0);
            glClear(GL_COLOR_BUFFER_BIT);
            glfwSwapBuffers(window);
            glfwHideWindow(window);
            uint32_t value = 0;
            set_x_cardinal_property(x11_display, x11_window, overlay_atom, value);
            mangoapp_paused = true;
            if (key_events)
                select_key_events(true);
            // pause all GPUs threads
            if (gpus)
                for (auto gpu : gpus->available_gpus)
                    gpu->pause();
        } else if (key_events) {
            handle_key_events(500, *real_params);
        } else {
            usleep(500000);
        }
    }

    shutdown(window);

    glfwTerminate();

    return 0;
}
