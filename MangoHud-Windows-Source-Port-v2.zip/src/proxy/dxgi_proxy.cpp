#include <windows.h>
#include <cstdio>
#include <string>
#include <vector>
#include <cstring>
#include <cstdlib>
#include "../win/kiero.h"
#include "../blacklist.h"

#if KIERO_INCLUDE_D3D11
#include "../win/d3d11_hook.h"
#endif
#if KIERO_INCLUDE_D3D12
#include "../win/d3d12_hook.h"
#endif

static HMODULE s_realDXGI = nullptr;
static INIT_ONCE s_realDXGIOnce = INIT_ONCE_STATIC_INIT;
static volatile LONG s_hooksInitStarted = 0;
static volatile LONG s_initFailed = 0;

static bool isStandaloneOverlayHost() {
    char modulePath[MAX_PATH] = {};
    const DWORD len = GetModuleFileNameA(nullptr, modulePath, MAX_PATH);
    if (len == 0 || len >= MAX_PATH)
        return false;

    std::string exeName(modulePath, len);
    const size_t slash = exeName.find_last_of("\\/");
    if (slash != std::string::npos)
        exeName.erase(0, slash + 1);

    return _stricmp(exeName.c_str(), "MangoHud.exe") == 0;
}

static BOOL CALLBACK loadSystemDXGI(PINIT_ONCE, PVOID, PVOID*) {
    char sysDir[MAX_PATH] = {};
    const UINT length = GetSystemDirectoryA(sysDir, MAX_PATH);
    if (length == 0 || length >= MAX_PATH)
        return FALSE;

    std::string path(sysDir, length);
    path += "\\dxgi.dll";
    // Load the real system DLL lazily, outside DllMain/loader lock.
    s_realDXGI = LoadLibraryA(path.c_str());
    return s_realDXGI != nullptr;
}

static bool ensureRealDXGI() {
    return InitOnceExecuteOnce(&s_realDXGIOnce, loadSystemDXGI, nullptr, nullptr) != FALSE
        && s_realDXGI != nullptr;
}

static DWORD WINAPI initOverlayThread(LPVOID) {
    if (isStandaloneOverlayHost() || is_blacklisted())
        return 0;

    // Present/ResizeBuffers may resolve to the same DXGI implementation for
    // D3D11 and D3D12. MinHook cannot safely install two different detours on
    // the same address, so select one renderer per process instead of racing
    // two independent hook sets. D3D12 is preferred when both runtimes are
    // loaded; applications can explicitly choose with MANGOHUD_DXGI_API.
    const char* apiOverride = getenv("MANGOHUD_DXGI_API");
    const bool forceD3D11 = apiOverride && _stricmp(apiOverride, "D3D11") == 0;
    const bool forceD3D12 = apiOverride && _stricmp(apiOverride, "D3D12") == 0;
    const bool hasOverride = forceD3D11 || forceD3D12;

    for (unsigned int attempt = 0; attempt < 20; ++attempt) {
        const bool hasD3D11 = GetModuleHandleA("d3d11.dll") != nullptr;
        const bool hasD3D12 = GetModuleHandleA("d3d12.dll") != nullptr;

        if (hasOverride) {
            if (forceD3D12 && hasD3D12) {
                const auto status = kiero::init(kiero::RenderType::D3D12);
                if ((status == kiero::Status::Success || status == kiero::Status::AlreadyInitializedError)
                    && impl::d3d12::init())
                    return 0;
            } else if (forceD3D11 && hasD3D11) {
                const auto status = kiero::init(kiero::RenderType::D3D11);
                if ((status == kiero::Status::Success || status == kiero::Status::AlreadyInitializedError)
                    && impl::d3d11::init())
                    return 0;
            }
        } else {
#if KIERO_INCLUDE_D3D12
            if (hasD3D12) {
                const auto status = kiero::init(kiero::RenderType::D3D12);
                if ((status == kiero::Status::Success || status == kiero::Status::AlreadyInitializedError)
                    && impl::d3d12::init())
                    return 0;
            }
#endif
#if KIERO_INCLUDE_D3D11
            if (!hasD3D12 && hasD3D11) {
                const auto status = kiero::init(kiero::RenderType::D3D11);
                if ((status == kiero::Status::Success || status == kiero::Status::AlreadyInitializedError)
                    && impl::d3d11::init())
                    return 0;
            }
#endif
        }

        // Keep waiting while the requested runtime has not appeared yet. If a
        // renderer is present but its dummy-device/hook setup fails, retry a
        // few times because startup and driver initialization can be transient.
        Sleep(250);
    }

    InterlockedExchange(&s_initFailed, 1);
    return 0;
}

static void initOverlayHooks() {
    if (InterlockedCompareExchange(&s_initFailed, 0, 0) != 0)
        return;

    const char* disable_hooks = getenv("MANGOHUD_DISABLE_DXGI_PROXY_HOOKS");
    if (disable_hooks && strcmp(disable_hooks, "1") == 0)
        return;

    if (InterlockedCompareExchange(&s_hooksInitStarted, 1, 0) != 0)
        return;

    // Never perform DirectX setup on the thread that is creating the DXGI factory.
    HANDLE thread = CreateThread(nullptr, 0, initOverlayThread, nullptr, 0, nullptr);
    if (thread)
        CloseHandle(thread);
    else
        InterlockedExchange(&s_hooksInitStarted, 0);
}

template<typename T>
static T getRealProc(const char* name) {
    if (!ensureRealDXGI()) return nullptr;
    return (T)GetProcAddress(s_realDXGI, name);
}

typedef HRESULT (WINAPI *PFN_CreateDXGIFactory)(REFIID, void**);
typedef HRESULT (WINAPI *PFN_CreateDXGIFactory1)(REFIID, void**);
typedef HRESULT (WINAPI *PFN_CreateDXGIFactory2)(UINT, REFIID, void**);
typedef HRESULT (WINAPI *PFN_DXGIGetDebugInterface1)(UINT, REFIID, void**);
typedef HRESULT (WINAPI *PFN_DXGIDeclareAdapterRemovalSupport)(void);
typedef HRESULT (WINAPI *PFN_DXGIDisableVBlankVirtualization)(void);

#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wmissing-declarations"

extern "C" {

__declspec(dllexport) HRESULT WINAPI CreateDXGIFactory(REFIID riid, void** ppFactory) {
    auto real = getRealProc<PFN_CreateDXGIFactory>("CreateDXGIFactory");
    if (!real) return E_FAIL;
    HRESULT hr = real(riid, ppFactory);
    if (SUCCEEDED(hr)) initOverlayHooks();
    return hr;
}

__declspec(dllexport) HRESULT WINAPI CreateDXGIFactory1(REFIID riid, void** ppFactory) {
    auto real = getRealProc<PFN_CreateDXGIFactory1>("CreateDXGIFactory1");
    if (!real) return E_FAIL;
    HRESULT hr = real(riid, ppFactory);
    if (SUCCEEDED(hr)) initOverlayHooks();
    return hr;
}

__declspec(dllexport) HRESULT WINAPI CreateDXGIFactory2(UINT Flags, REFIID riid, void** ppFactory) {
    auto real = getRealProc<PFN_CreateDXGIFactory2>("CreateDXGIFactory2");
    if (!real) return E_FAIL;
    HRESULT hr = real(Flags, riid, ppFactory);
    if (SUCCEEDED(hr)) initOverlayHooks();
    return hr;
}

__declspec(dllexport) HRESULT WINAPI DXGIGetDebugInterface1(UINT Flags, REFIID riid, void** pDebug) {
    auto real = getRealProc<PFN_DXGIGetDebugInterface1>("DXGIGetDebugInterface1");
    if (!real) return E_FAIL;
    return real(Flags, riid, pDebug);
}

__declspec(dllexport) HRESULT WINAPI DXGIDeclareAdapterRemovalSupport(void) {
    auto real = getRealProc<PFN_DXGIDeclareAdapterRemovalSupport>("DXGIDeclareAdapterRemovalSupport");
    if (!real) return E_FAIL;
    return real();
}

__declspec(dllexport) HRESULT WINAPI DXGIDisableVBlankVirtualization(void) {
    auto real = getRealProc<PFN_DXGIDisableVBlankVirtualization>("DXGIDisableVBlankVirtualization");
    if (!real) return E_NOTIMPL; // Not exported by older Windows DXGI versions.
    return real();
}

} // extern "C"

#pragma GCC diagnostic pop

BOOL WINAPI DllMain(HINSTANCE hInstance, DWORD fdwReason, LPVOID) {
    if (fdwReason == DLL_PROCESS_ATTACH)
        DisableThreadLibraryCalls(hInstance);
    // Keep DllMain loader-lock safe: no LoadLibrary, threads, logging or hooks here.
    return TRUE;
}
