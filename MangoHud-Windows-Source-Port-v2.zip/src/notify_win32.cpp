// Windows implementation of MangoHud configuration file monitoring.
// Polling intentionally avoids invasive process-wide hooks.
#include "notify.h"
#include "config.h"
#include <filesystem>
#include <chrono>
#include <thread>
#include <cstdlib>

namespace fs = std::filesystem;

static void watch_config(notify_thread* nt) {
    fs::file_time_type previous{};
    std::string watched;
    while (!nt->quit.load()) {
        std::this_thread::sleep_for(std::chrono::milliseconds(500));
        if (!nt->params) continue;
        std::string path;
        { std::lock_guard<std::mutex> lock(nt->mutex); path = nt->params->config_file_path; }
        if (path.empty()) continue;
        std::error_code ec;
        auto current = fs::last_write_time(path, ec);
        if (ec) continue;
        if (watched != path) { watched = path; previous = current; continue; }
        if (current == previous) continue;
        previous = current;
        overlay_params updated;
        { std::lock_guard<std::mutex> lock(nt->mutex); updated = *nt->params; }
        parse_overlay_config(&updated, std::getenv("MANGOHUD_CONFIG"), false);
        { std::lock_guard<std::mutex> lock(nt->mutex); *nt->params = updated; }
    }
}

bool start_notifier(notify_thread& nt) {
    if (!nt.params) return false;
    nt.quit.store(false);
    if (nt.thread.joinable()) { nt.quit.store(true); nt.thread.join(); nt.quit.store(false); }
    nt.thread = std::thread(watch_config, &nt);
    return true;
}

notify_thread::~notify_thread() {
    quit.store(true);
    if (thread.joinable()) thread.join();
}
