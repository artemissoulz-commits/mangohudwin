#include "kiero.h"
#include <windows.h>
#include <dxgi.h>
#include <cstdint>
#include "dxgi.h"

uint32_t get_device_id_dxgi()
{
    // The proxy exports CreateDXGIFactory and forwards it to the real system
    // DXGI module. Using GetModuleHandle here is intentional: it resolves the
    // proxy when MangoHud is deployed beside a game executable.
    HMODULE libDXGI = GetModuleHandleA("dxgi.dll");
    if (!libDXGI)
        return 0;

    auto createFactory = reinterpret_cast<decltype(&::CreateDXGIFactory)>(
        GetProcAddress(libDXGI, "CreateDXGIFactory"));
    if (!createFactory)
        return 0;

    IDXGIFactory* factory = nullptr;
    if (FAILED(createFactory(__uuidof(IDXGIFactory), reinterpret_cast<void**>(&factory))) || !factory)
        return 0;

    uint32_t vendorId = 0;
    for (UINT index = 0; ; ++index) {
        IDXGIAdapter* adapter = nullptr;
        const HRESULT enumResult = factory->EnumAdapters(index, &adapter);
        if (enumResult == DXGI_ERROR_NOT_FOUND)
            break;
        if (FAILED(enumResult) || !adapter)
            break;

        DXGI_ADAPTER_DESC desc = {};
        if (SUCCEEDED(adapter->GetDesc(&desc)) &&
            (desc.VendorId == 0x10de || desc.VendorId == 0x1002 || desc.VendorId == 0x8086)) {
            vendorId = desc.VendorId;
            adapter->Release();
            break;
        }
        adapter->Release();
    }

    factory->Release();
    return vendorId;
}
