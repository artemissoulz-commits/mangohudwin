#include "kiero.h"

#if KIERO_INCLUDE_D3D12

#include <cstdio>
#include <cassert>
#include "d3d12_hook.h"
#include "d3d_shared.h"
#include "../overlay.h"
#include "../hud_elements.h"
#include <d3d12.h>
#include <dxgi1_4.h>
#include <mutex>
#include <imgui.h>
#include <implot.h>
#include "imgui_impl_win32.h"

// ImGui DX12 backend is only available on MSVC builds (MinGW lacks required headers)
#ifdef _MSC_VER
#include "imgui_impl_dx12.h"
#define HAS_IMGUI_DX12 1
#else
#define HAS_IMGUI_DX12 0
#endif

static const UINT MAX_BACK_BUFFERS = 8;
static const DWORD FENCE_WAIT_TIMEOUT_MS = 5000;

// Kiero D3D12 vtable layout (from kiero.cpp):
//   [0..43]   ID3D12Device          (44 methods)
//   [44..62]  ID3D12CommandQueue     (19 methods)
//   [63..71]  ID3D12CommandAllocator  (9 methods)
//   [72..131] ID3D12GraphicsCommandList (60 methods)
//   [132..149] IDXGISwapChain        (18 methods)
//
// Present          = swapchain vtable index 8  -> kiero index 132 + 8  = 140
// ResizeBuffers    = swapchain vtable index 13 -> kiero index 132 + 13 = 145
// ExecuteCommandLists = commandQueue vtable index 10 -> kiero index 44 + 10 = 54
static const int KIERO_IDX_PRESENT             = 140;
static const int KIERO_IDX_RESIZE_BUFFERS      = 145;
static const int KIERO_IDX_EXECUTE_CMD_LISTS   = 54;

typedef long(__fastcall* PresentD3D12)(IDXGISwapChain*, UINT, UINT);
typedef void(__fastcall* ExecuteCommandListsFn)(ID3D12CommandQueue*, UINT, ID3D12CommandList* const*);
typedef HRESULT(__stdcall* ResizeBuffers12Fn)(IDXGISwapChain*, UINT, UINT, UINT, DXGI_FORMAT, UINT);

static PresentD3D12 oPresentD3D12 = nullptr;
static ExecuteCommandListsFn oExecuteCommandLists = nullptr;
static ResizeBuffers12Fn oResizeBuffers12 = nullptr;
static std::mutex d3d12QueueMutex;

#if HAS_IMGUI_DX12
static ID3D12Device* d3d12Device = nullptr;
static ID3D12CommandQueue* d3d12CommandQueue = nullptr;
static ID3D12DescriptorHeap* d3d12SrvDescHeap = nullptr;
static ID3D12DescriptorHeap* d3d12RtvDescHeap = nullptr;
static ID3D12CommandAllocator* d3d12CommandAllocators[MAX_BACK_BUFFERS] = {};
static ID3D12GraphicsCommandList* d3d12CommandList = nullptr;
static ID3D12Resource* d3d12BackBuffers[MAX_BACK_BUFFERS] = {};
static D3D12_CPU_DESCRIPTOR_HANDLE d3d12RtvHandles[MAX_BACK_BUFFERS] = {};
static ID3D12Fence* d3d12Fence = nullptr;
static HANDLE d3d12FenceEvent = nullptr;
static UINT64 d3d12FenceLastSignaledValue = 0;
static UINT64 d3d12FenceValues[MAX_BACK_BUFFERS] = {};
static bool d3d12_imgui_inited = false;
static bool d3d12FenceFailed = false;
static UINT numBackBuffers = 0;

static bool wait_for_fence_value(UINT64 value) {
    if (!d3d12Fence || !d3d12FenceEvent)
        return false;

    const UINT64 completed = d3d12Fence->GetCompletedValue();
    if (completed == UINT64_MAX) {
        d3d12FenceFailed = true; // Device removed; never reuse allocators.
        return false;
    }
    if (completed >= value)
        return true;

    if (FAILED(d3d12Fence->SetEventOnCompletion(value, d3d12FenceEvent)))
        return false;
    return WaitForSingleObject(d3d12FenceEvent, FENCE_WAIT_TIMEOUT_MS) == WAIT_OBJECT_0;
}

static bool wait_for_frame_allocator(UINT backBufferIndex) {
    if (backBufferIndex >= MAX_BACK_BUFFERS)
        return false;
    const UINT64 value = d3d12FenceValues[backBufferIndex];
    return value == 0 || wait_for_fence_value(value);
}

static bool wait_for_gpu_idle() {
    if (!d3d12CommandQueue || !d3d12Fence)
        return false;

    const UINT64 value = ++d3d12FenceLastSignaledValue;
    if (FAILED(d3d12CommandQueue->Signal(d3d12Fence, value)))
        return false;
    if (!wait_for_fence_value(value))
        return false;

    for (UINT i = 0; i < MAX_BACK_BUFFERS; ++i)
        d3d12FenceValues[i] = 0;
    return true;
}

static void cleanup_render_targets() {
    for (UINT i = 0; i < MAX_BACK_BUFFERS; i++) {
        if (d3d12BackBuffers[i]) {
            d3d12BackBuffers[i]->Release();
            d3d12BackBuffers[i] = nullptr;
        }
    }
}

static void cleanup_d3d12() {
    if (d3d12CommandList) { d3d12CommandList->Release(); d3d12CommandList = nullptr; }
    for (UINT i = 0; i < MAX_BACK_BUFFERS; i++) {
        if (d3d12CommandAllocators[i]) {
            d3d12CommandAllocators[i]->Release();
            d3d12CommandAllocators[i] = nullptr;
        }
    }
    cleanup_render_targets();
    if (d3d12RtvDescHeap) { d3d12RtvDescHeap->Release(); d3d12RtvDescHeap = nullptr; }
    if (d3d12SrvDescHeap) { d3d12SrvDescHeap->Release(); d3d12SrvDescHeap = nullptr; }
    if (d3d12Fence) { d3d12Fence->Release(); d3d12Fence = nullptr; }
    if (d3d12FenceEvent) { CloseHandle(d3d12FenceEvent); d3d12FenceEvent = nullptr; }
    if (d3d12Device) { d3d12Device->Release(); d3d12Device = nullptr; }
    {
        std::lock_guard<std::mutex> lock(d3d12QueueMutex);
        if (d3d12CommandQueue) {
            d3d12CommandQueue->Release();
            d3d12CommandQueue = nullptr;
        }
    }
    d3d12FenceLastSignaledValue = 0;
    for (UINT i = 0; i < MAX_BACK_BUFFERS; ++i)
        d3d12FenceValues[i] = 0;
    d3d12_imgui_inited = false;
    d3d12FenceFailed = false;
    numBackBuffers = 0;
}

static bool create_render_targets(IDXGISwapChain* pSwapChain) {
    if (numBackBuffers == 0 || numBackBuffers > MAX_BACK_BUFFERS || !d3d12RtvDescHeap)
        return false;

    for (UINT i = 0; i < numBackBuffers; i++) {
        if (FAILED(pSwapChain->GetBuffer(i, IID_PPV_ARGS(&d3d12BackBuffers[i])))) {
            cleanup_render_targets();
            return false;
        }
        d3d12Device->CreateRenderTargetView(d3d12BackBuffers[i], nullptr, d3d12RtvHandles[i]);
    }
    return true;
}

static bool init_d3d12_imgui(IDXGISwapChain* pSwapChain) {
    if (!d3d12CommandQueue)
        return false;

    HRESULT hr = pSwapChain->GetDevice(__uuidof(ID3D12Device), (void**)&d3d12Device);
    if (FAILED(hr) || !d3d12Device)
        return false;

    DXGI_SWAP_CHAIN_DESC sd = {};
    if (FAILED(pSwapChain->GetDesc(&sd)) || sd.BufferCount == 0 || sd.BufferCount > MAX_BACK_BUFFERS) {
        cleanup_d3d12();
        return false;
    }
    numBackBuffers = sd.BufferCount;

    // Create SRV descriptor heap (for ImGui font texture)
    {
        D3D12_DESCRIPTOR_HEAP_DESC desc = {};
        desc.Type = D3D12_DESCRIPTOR_HEAP_TYPE_CBV_SRV_UAV;
        desc.NumDescriptors = 1;
        desc.Flags = D3D12_DESCRIPTOR_HEAP_FLAG_SHADER_VISIBLE;
        if (FAILED(d3d12Device->CreateDescriptorHeap(&desc, IID_PPV_ARGS(&d3d12SrvDescHeap)))) {
            cleanup_d3d12();
            return false;
        }
    }

    // Create RTV descriptor heap
    {
        D3D12_DESCRIPTOR_HEAP_DESC desc = {};
        desc.Type = D3D12_DESCRIPTOR_HEAP_TYPE_RTV;
        // Reserve the full supported range so ResizeBuffers can change the
        // swap-chain buffer count without writing past the descriptor heap.
        desc.NumDescriptors = MAX_BACK_BUFFERS;
        desc.Flags = D3D12_DESCRIPTOR_HEAP_FLAG_NONE;
        if (FAILED(d3d12Device->CreateDescriptorHeap(&desc, IID_PPV_ARGS(&d3d12RtvDescHeap)))) {
            cleanup_d3d12();
            return false;
        }

        SIZE_T rtvDescriptorSize = d3d12Device->GetDescriptorHandleIncrementSize(D3D12_DESCRIPTOR_HEAP_TYPE_RTV);
        D3D12_CPU_DESCRIPTOR_HANDLE rtvHandle = d3d12RtvDescHeap->GetCPUDescriptorHandleForHeapStart();
        for (UINT i = 0; i < MAX_BACK_BUFFERS; i++) {
            d3d12RtvHandles[i] = rtvHandle;
            rtvHandle.ptr += rtvDescriptorSize;
        }
    }

    // Create one command allocator per supported back-buffer index.
    for (UINT i = 0; i < MAX_BACK_BUFFERS; i++) {
        if (FAILED(d3d12Device->CreateCommandAllocator(D3D12_COMMAND_LIST_TYPE_DIRECT, IID_PPV_ARGS(&d3d12CommandAllocators[i])))) {
            cleanup_d3d12();
            return false;
        }
    }

    if (FAILED(d3d12Device->CreateFence(0, D3D12_FENCE_FLAG_NONE, IID_PPV_ARGS(&d3d12Fence)))) {
        cleanup_d3d12();
        return false;
    }
    d3d12FenceEvent = CreateEventW(nullptr, FALSE, FALSE, nullptr);
    if (!d3d12FenceEvent) {
        cleanup_d3d12();
        return false;
    }

    if (!create_render_targets(pSwapChain)) {
        cleanup_d3d12();
        return false;
    }

    if (FAILED(d3d12Device->CreateCommandList(0, D3D12_COMMAND_LIST_TYPE_DIRECT,
            d3d12CommandAllocators[0], nullptr, IID_PPV_ARGS(&d3d12CommandList)))) {
        cleanup_d3d12();
        return false;
    }
    if (FAILED(d3d12CommandList->Close())) {
        cleanup_d3d12();
        return false;
    }

    ImGui::CreateContext();
    ImPlot::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.IniFilename = nullptr;
    io.DisplaySize = ImVec2((float)sd.BufferDesc.Width, (float)sd.BufferDesc.Height);
    ImGui::StyleColorsDark();
    HUDElements.convert_colors(false, params);

    const bool win32Ready = ImGui_ImplWin32_Init(sd.OutputWindow);
    const bool dx12Ready = win32Ready && ImGui_ImplDX12_Init(d3d12Device, MAX_BACK_BUFFERS,
        sd.BufferDesc.Format, d3d12SrvDescHeap,
        d3d12SrvDescHeap->GetCPUDescriptorHandleForHeapStart(),
        d3d12SrvDescHeap->GetGPUDescriptorHandleForHeapStart());
    if (!win32Ready || !dx12Ready) {
        if (dx12Ready)
            ImGui_ImplDX12_Shutdown();
        if (win32Ready)
            ImGui_ImplWin32_Shutdown();
        ImPlot::DestroyContext();
        ImGui::DestroyContext();
        cleanup_d3d12();
        return false;
    }

    create_fonts(nullptr, params, sw_stats.font_small, sw_stats.font_text, sw_stats.font_secondary);
    sw_stats.font_params_hash = params.font_params_hash;

    d3d12_imgui_inited = true;
    return true;
}
#else
// MinGW: no ImGui DX12 backend, just capture the command queue for future use
static ID3D12CommandQueue* d3d12CommandQueue = nullptr;
#endif // HAS_IMGUI_DX12

long __fastcall hkPresent12(IDXGISwapChain3* pSwapChain, UINT SyncInterval, UINT Flags)
{
    dx_version = kiero::RenderType::D3D12;

#if HAS_IMGUI_DX12
    if (!d3d12_imgui_inited)
        init_d3d12_imgui(pSwapChain);

    if (d3d12_imgui_inited && d3d12CommandQueue && !d3d12FenceFailed) {
        d3d_run();

        const UINT backBufferIdx = pSwapChain->GetCurrentBackBufferIndex();
        if (backBufferIdx >= numBackBuffers || backBufferIdx >= MAX_BACK_BUFFERS ||
            !wait_for_frame_allocator(backBufferIdx)) {
            d3d12FenceFailed = true;
            return oPresentD3D12(pSwapChain, SyncInterval, Flags);
        }

        DXGI_SWAP_CHAIN_DESC sd;
        pSwapChain->GetDesc(&sd);
        ImGui::GetIO().DisplaySize = ImVec2((float)sd.BufferDesc.Width, (float)sd.BufferDesc.Height);

        if (HUDElements.colors.update)
            HUDElements.convert_colors(params);

        if (FAILED(d3d12CommandAllocators[backBufferIdx]->Reset()) ||
            FAILED(d3d12CommandList->Reset(d3d12CommandAllocators[backBufferIdx], nullptr)))
            return oPresentD3D12(pSwapChain, SyncInterval, Flags);

        D3D12_RESOURCE_BARRIER barrier = {};
        barrier.Type = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;
        barrier.Flags = D3D12_RESOURCE_BARRIER_FLAG_NONE;
        barrier.Transition.pResource = d3d12BackBuffers[backBufferIdx];
        barrier.Transition.StateBefore = D3D12_RESOURCE_STATE_PRESENT;
        barrier.Transition.StateAfter = D3D12_RESOURCE_STATE_RENDER_TARGET;
        barrier.Transition.Subresource = D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;
        d3d12CommandList->ResourceBarrier(1, &barrier);

        d3d12CommandList->OMSetRenderTargets(1, &d3d12RtvHandles[backBufferIdx], FALSE, nullptr);
        d3d12CommandList->SetDescriptorHeaps(1, &d3d12SrvDescHeap);

        ImGui_ImplDX12_NewFrame();
        ImGui_ImplWin32_NewFrame();
        ImGui::NewFrame();

        overlay_new_frame(params);
        position_layer(sw_stats, params, window_size);
        render_imgui(sw_stats, params, window_size, false);
        overlay_end_frame();

        ImGui::Render();
        ImGui_ImplDX12_RenderDrawData(ImGui::GetDrawData(), d3d12CommandList);

        barrier.Transition.StateBefore = D3D12_RESOURCE_STATE_RENDER_TARGET;
        barrier.Transition.StateAfter = D3D12_RESOURCE_STATE_PRESENT;
        d3d12CommandList->ResourceBarrier(1, &barrier);

        if (SUCCEEDED(d3d12CommandList->Close())) {
            ID3D12CommandList* ppCommandLists[] = { d3d12CommandList };
            d3d12CommandQueue->ExecuteCommandLists(1, ppCommandLists);

            // The allocator for this back buffer cannot be reset until the GPU
            // has completed the overlay command list submitted above.
            const UINT64 fenceValue = ++d3d12FenceLastSignaledValue;
            if (SUCCEEDED(d3d12CommandQueue->Signal(d3d12Fence, fenceValue)))
                d3d12FenceValues[backBufferIdx] = fenceValue;
            else
                d3d12FenceFailed = true; // Stop rendering rather than reusing an in-flight allocator.
        }

        if (sw_stats.font_params_hash != params.font_params_hash) {
            sw_stats.font_params_hash = params.font_params_hash;
            create_fonts(nullptr, params, sw_stats.font_small, sw_stats.font_text, sw_stats.font_secondary);
            ImGui_ImplDX12_InvalidateDeviceObjects();
            ImGui_ImplDX12_CreateDeviceObjects();
        }
    }
#else
    // MinGW fallback: stats collection only, no overlay rendering for D3D12
    d3d_run();
#endif

    return oPresentD3D12(pSwapChain, SyncInterval, Flags);
}

void __fastcall hkExecuteCommandLists12(ID3D12CommandQueue* queue, UINT NumCommandLists, ID3D12CommandList* const* ppCommandLists)
{
    {
        std::lock_guard<std::mutex> lock(d3d12QueueMutex);
        if (!d3d12CommandQueue) {
            D3D12_COMMAND_QUEUE_DESC desc = queue->GetDesc();
            if (desc.Type == D3D12_COMMAND_LIST_TYPE_DIRECT) {
                queue->AddRef();
                d3d12CommandQueue = queue;
            }
        }
    }
    oExecuteCommandLists(queue, NumCommandLists, ppCommandLists);
}

HRESULT __stdcall hkResizeBuffers12(IDXGISwapChain* pSwapChain, UINT BufferCount, UINT Width, UINT Height, DXGI_FORMAT NewFormat, UINT SwapChainFlags)
{
#if HAS_IMGUI_DX12
    // Never release swap-chain buffers while the overlay command list is in flight.
    const bool overlayActive = d3d12_imgui_inited;
    const bool gpuIdle = !overlayActive || wait_for_gpu_idle();
    if (!gpuIdle) {
        d3d12FenceFailed = true;
        // The device/queue is no longer safe to synchronize. Do not release
        // resources that the GPU might still be using or forward a resize that
        // would invalidate those resources.
        return DXGI_ERROR_DEVICE_REMOVED;
    }
    if (overlayActive)
        cleanup_render_targets();
#endif

    HRESULT hr = oResizeBuffers12(pSwapChain, BufferCount, Width, Height, NewFormat, SwapChainFlags);

#if HAS_IMGUI_DX12
    if (SUCCEEDED(hr) && d3d12Device && overlayActive) {
        DXGI_SWAP_CHAIN_DESC sd = {};
        if (SUCCEEDED(pSwapChain->GetDesc(&sd)) && sd.BufferCount > 0 && sd.BufferCount <= MAX_BACK_BUFFERS) {
            numBackBuffers = sd.BufferCount;
            if (!create_render_targets(pSwapChain)) {
                numBackBuffers = 0;
                d3d12FenceFailed = true;
            }
        } else {
            // Unsupported buffer counts are handled by skipping overlay rendering.
            numBackBuffers = 0;
            d3d12FenceFailed = true;
        }
    }
#endif
    return hr;
}

bool impl::d3d12::init()
{
    auto ret = kiero::bind(kiero::RenderType::D3D12, KIERO_IDX_PRESENT, (void**)&oPresentD3D12, reinterpret_cast<void*>(hkPresent12));
    if (ret != kiero::Status::Success)
        return false;

    ret = kiero::bind(kiero::RenderType::D3D12, KIERO_IDX_EXECUTE_CMD_LISTS, (void**)&oExecuteCommandLists, reinterpret_cast<void*>(hkExecuteCommandLists12));
    if (ret != kiero::Status::Success) {
        kiero::unbind(kiero::RenderType::D3D12, KIERO_IDX_PRESENT);
        return false;
    }

    ret = kiero::bind(kiero::RenderType::D3D12, KIERO_IDX_RESIZE_BUFFERS, (void**)&oResizeBuffers12, reinterpret_cast<void*>(hkResizeBuffers12));
    if (ret != kiero::Status::Success) {
        kiero::unbind(kiero::RenderType::D3D12, KIERO_IDX_PRESENT);
        kiero::unbind(kiero::RenderType::D3D12, KIERO_IDX_EXECUTE_CMD_LISTS);
        return false;
    }

    init_d3d_shared();
    return true;
}

#endif // KIERO_INCLUDE_D3D12
